import java.util.ArrayList;

public class Equipo{
    private ArrayList<Persona> personas = new ArrayList<Persona>();
    
    /**
     * Crea un equipo dado el nombre de sus miembros
     * @param nombres nombres de los miembros del equipo
     */    
    public Equipo(String [] nombres){
        personas= new ArrayList<Persona>();
        for (int i=0; i< nombres.length;i++){
            personas.add(new Persona(nombres[i]));
        }    
    }

    /**
     * Calcula el valor hora de un equipo
     */
    public int valorHora() throws EquipoExcepcion{
        int valorHora = 0;
        if( personas.size() == 0 ){
            throw new EquipoExcepcion( EquipoExcepcion.EQUIPO_VACIO);
        }
        for ( Persona p: personas){
            valorHora+= p.valorHora();
        }
        return valorHora;
    }
    
    /**
     * Calcula el valor hora estimado de un equipo.
     * El valor estimado de una persona a la que no se conoce su valor es la
     * media de los valores conocidos
     * Más del 75% del equipo debe tener valores conocidos 
     * @return el valor hora del equipo
     * @throws EquipoException si en el equipo hay una persona desconocida
     * o si no es posible calular el valor estimado
     */
    public int valorHoraEstimado() throws EquipoExcepcion{
        double valorEstimado = 0, size = personas.size(), cont = 0,persona ;
        
        if ( size == 0.0){
            throw new EquipoExcepcion( EquipoExcepcion.EQUIPO_VACIO);
        }
        for( Persona p: personas ){
            try{
                 valorEstimado+= p.valorHora();
                 cont++;
            }
            catch( EquipoExcepcion exception ){
                if ( EquipoExcepcion.PERSONA_DESCONOCIDA.equals( exception.getMessage() )){
                    throw new EquipoExcepcion( EquipoExcepcion.PERSONA_DESCONOCIDA  );
                }
            }
        } 
        if ( cont/size  <= 0.75  ){
            throw new EquipoExcepcion( EquipoExcepcion.NO_ES_POSIBLE_CALCULAR);
        }

        return (int)(valorEstimado + ( (size- cont ) * (valorEstimado/ cont) ) );
        
    }       
}
