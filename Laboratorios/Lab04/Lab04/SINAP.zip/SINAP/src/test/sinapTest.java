
package test;

import aplicacion.*;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;




public class sinapTest {
   
	@Test
	public void deberiaAdicionar() {
		Sinap sinap = new Sinap();
		Area[] areas = {new Area("Laguna de Guatavita","Laguna de Guatavita","Sesquile","2000"," La laguna esta a una de altitud de 3.100 m s. n. m. y a una temperatura de 5 a 11c. Es una depresi�n monta�osa de forma perfectamente circular, con cerca 700 m de di�metro, rodeada de bosques nativos de encenillos"),
						new Area("Laguna De Tota","Laguna De Tota","Boyaca","52 km^2","El lago de Tota es un cuerpo de agua natural situado en el departamento de Boyaca, Colombia, en jurisdiccion de los municipios de Cuitiva, Tota y Aquitania. Se encuentra ubicado a 34 km al sur de Sogamoso, aproximadamente 200 km al noroeste de Bogota, la capital del pais.")};
		
		for (Area a : areas ){
			sinap.adicioneDetalles( a );
			assertEquals( a, sinap.getDetalles(a.getNombre(),a.getName()));
		}		
	}	
		
	@Test
	public void deberiaEnlistar() {
		Sinap sinap = new Sinap();
		Area area = new Area("Laguna de Guatavita","Laguna de Guatavita","Sesquile","2000","La laguna esta a una de altitud de 3.100 m s. n. m.");
		sinap.adicioneDetalles( area );
		Area areaTest = sinap.getDetalles(area.getNombre(),area.getName() );
		assertEquals( areaTest.toString(),area.toString());
		
	}
}					