import java.util.HashMap;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.io.*;

/**
 * The Board class will be the abstraction 
 * of the object "Chinese checkerboard"
 *
 * @author Iván Camilo Rincón Saavedra
 * @author Miguel Angel Fuquene Arias
 * 
 * @version 1.0 (04/02/2020)
 * @version 2.0 (05/02/2020)
 * @version 3.0 (06/02/2020)
 * @version 4.0 (15/02/2020)
 * @version 5.0 (17/02/2020)
 * @version 6.0 (21/02/2020)
 * @version 7.0 (22/02/2020)
 */
public class Board
{
    private static final  int sizeRec = 30 ;
    private int numberOfPieces = 0;
    private int size;
    private int direction; 
    private int xPositionT;
    private int val = 1;
    private boolean typePiece = false;
    private String color;
    private String lecture;
    private int[] selected =   new int[]{ 0, -10, -10} ;
    private Rectangle[][] board;
    private Piece[][] boardOfPieces; 
    private Piece arrow;
    
    /**
     * Constructor for objects of class Board
     * @param you enter the size that the board will receive,
     * integer type called newSize
     */
    public Board( int newSize ){
        board = new Rectangle[newSize][newSize];
        boardOfPieces = new Piece[newSize][newSize];

        xPositionT = 0;
        size = newSize;  
    }

    
    /**
     * method that modifies the position from which the board is drawn
     * @param newPos ,enter the new start position of the board 
     */
    public void setXpos( int newPos ){
        xPositionT = newPos;
    }

    /**
     * method that get the position from which the board is drawn
     * @return the start drawing position of the board
     */
    public int getXpos( ){
        return xPositionT  ;
    }

    /**
     * method that verifies the indices are valid
     * @param row, integer type variable, which represents a index
     * @param column, integer type variable, which represents a index  
     * @return a boolean that represent whether or not it is valid 
     */
    private boolean checkPos( int row, int column ){
        boolean ok = true;
        
        if (  ( row <= 0 ) || ( column <= 0 ) || ( row > size ) || ( column > size ) ){
            error( 8 );
            ok = false;
        }
        else if ( ( row + column )%2 == 0 ){
            error( 2 );
            ok = false;
        }
        return ok;
    }

    /**
     * method that draw's the Board 
     */
    public void draw(){
        Rectangle casilla;
        for ( int i = 0; i < size; i++ ){
            for ( int j = 0; j < size ; j++ ){

                if(  ( i + j ) % 2 == 0  ){ board[ i ][ j ] = null;}
                else if ( ( i + j ) % 2 != 0 ) {
                    casilla = new Rectangle();
                    
                    casilla.setXpos( sizeRec * j + xPositionT );
                    casilla.setYpos( i * sizeRec  );
                    casilla.makeVisible();
                    
                    board[ i ][ j ] =casilla;
                    
                }   
                boardOfPieces[ i ][ j ] = null;
            }   
        } 
    }
    
    /**
     * @param
       *makes the arrow associated with the configuration table visible 
       */
    public void makeVisibleArrow( int xPosition) {
       arrow = new Piece("blue", true, ( size/2 ) * sizeRec + xPosition, sizeRec * ( size + 1) );
       arrow.changeSize( 40,40);
       arrow.makeVisible(); 
    }
    
    /**
       *makes the arrow associated with the configuration table invisible 
       */
    public void makeInvisibleArrow( ){
       arrow.makeInvisible(); 
    }
    
    
    /**
     * method that places all pieces  
     */
    public void makeVisible(){
        for ( int i = 0; i < size  ; i++ ){
            for ( int j = 0; j < size; j++ ){ 
                if (  boardOfPieces[ i ][ j ] != null ){                
                    boardOfPieces[ i ][ j ].makeVisible();
                }
            }
        }

    }

    /**
     * method that places all  pieces  invisible
     */
    public void makeInvisible(){
        for ( int i = 0; i < size  ; i++ ){
            for ( int j = 0; j < size; j++ ){
                if (  boardOfPieces[ i ][ j ] != null ){
                    boardOfPieces[ i ][ j ].makeInvisible();
                }
            }
        }

    }
    
    /**
     * method that add's checkers from a board 
     * @param green, boolean that say if is green or not
     * @param row, integer type variable, which represents a index
     * @param column, integer type variable, which represents a index   
     */
    public void add( boolean green , boolean king, int row, int column ){
        int  x, xPos, yPos;
        Piece piece;
        Rectangle currentR;
       
        if ( checkPos( row, column ) ) {
            typePiece = ( (row == 0 && color == "red") || (  (row == size-1 && color == "green") ) ) ?true: king;
            direction = ( king == true ) ? 2: 8 ;
            
            if ( boardOfPieces[ row - 1 ][ column - 1 ] != null ){ error( 1 ); }
            else{
                xPos =  board[ row - 1 ][ column - 1 ].getXpos()+ sizeRec / direction;
                yPos = board[ row - 1 ][ column - 1 ].getYpos() +sizeRec / 8;

                piece = new Piece(  ( green  ) ? "green": "red" , king, xPos ,  yPos);
                piece.makeVisible();

                boardOfPieces[ row - 1 ][ column - 1 ] = piece;
                numberOfPieces++;
            }
            typePiece = false;

        }
    }

    /**
     * method that add's checkers from a board 
     * @param green, boolean that say if is green or not
     *@param menL, matrix of integers which represent the positions of the chips to be added
     */
    public void add( boolean green ,int[][] menL ){
        int row;
        int[] current;

        for ( row = 0; row < menL.length; row++ ){
            current = menL[ row ];                
            add( green , false,  current[ 0 ], current[ 1 ] );
        } 
    }

    /**
     * method that removes checkers from a board 
     *@param pieces, matrix of integers, which represent the positions of the chips to be removed
     */
    public void remove( int[][] pieces ){
        int row, column, x;
        int[] currentP ;

        for ( x = 0; x < pieces.length; x++ ){
            currentP = pieces[ x ];

            row = currentP[ 0 ];
            column = currentP[ 1 ];

            remove(  row,  column );
        }
    }

    /**
     * method that removes checkers from a board 
     *@param row, integer type variable, which represents a index
     *@param column, integer type variable, which represents a index 
     */
    public void remove( int row, int column ) {      
        if ( checkPos( row, column ) ){
            if ( boardOfPieces[ row - 1 ][ column - 1 ] != null  ){
                boardOfPieces[ row - 1 ][ column - 1 ].makeInvisible();
                boardOfPieces[ row - 1 ][ column - 1 ] = null;
                numberOfPieces--;
            }
            else{error( 3 );}
        }

            
    }

    /**
     * method that selects a piece and denotes a specific color 
     *@param row, integer type variable, which represents a index
     *@param column, integer type variable, which represents a index  
     */
    public void select(int row, int column){
        Piece currentPiece;
        
        if ( selected[0] == 0 ){
            if ( checkPos( row, column ) ){
                if ( boardOfPieces[ row - 1 ][ column - 1 ] != null ){
                    typePiece = boardOfPieces[ row - 1 ][ column - 1 ].getType();
                    color = boardOfPieces[ row - 1 ][ column - 1 ].getColor();
                    
                    boardOfPieces[ row - 1 ][ column - 1 ].changeColor(color,"yellow");          
                    selected = new int[]{ 1, row - 1 , column - 1,(typePiece)?1:0 };
                }
                else{ error( 3 ); }
            }
        }
        else{
            makeVisible();
            selected = new int[]{0, -10, -10,-1 };
        }
    }
    
    
    /**
     *method that moves a piece on the configuration board 
     *@param top, boolean that says if the piece moves up or down  
     *@param right,  boolean that says if the piece left or right  
     */
      
    public void shift( boolean top, boolean right  ){
        this.color = ( top ) ? "red":"green";
        move( ( right ) ? "right":"left" );        
    }
    
    /**
     * method that moves a piece in the direction it is assigned
     * @param notation, chain type variable that indicates which direction the part will take, it will take the left or right values
     */
    public void move( String notation ){
        int row, column, direccion ;
        boolean isLeft =  notation.toLowerCase()  == "left", isRight = notation.toLowerCase()  == "right" ;
        String color;
        Piece pieceTemp;
        
        if ( selected[ 0 ] == 1 ){
            if (  isLeft || isRight ){
                
                color =  boardOfPieces[  selected[ 1 ]  ][  selected[ 2 ] ].getColor();
                direction  = ( isLeft ) ? - val: val;
                row = ( this.color == "red" ) ?  selected[ 1 ] - val : selected[ 1 ]  + val ;
                column =  selected[ 2 ] + direction ;
                
                if ( ( row == 0 && color == "red" ) || ( row == size-1   && color == "green" ) ){
                    typePiece = true; 
                }
                
                if ( checkPos( row + 1, column + 1 ) ){
                    if ( boardOfPieces[ row ][ column ] == null ){
                        remove( selected[ 1 ] + 1  , selected[ 2 ] + 1);                        
                        add( color == "green",typePiece, row + 1 , column + 1);
                        selected[ 0 ] = 0;
                    }
                    else{ error( 5 );}
                }
                direction  = 0;
            }
            else{ error( 4 ); }
        }
        else{ error(6); }
    }
    
    
    /***
     * method that seeks to skip a token given its meaning
     *@param top, boolean that say if the jump is going to do on the top
     *@param rigth ,boolean that say if the jump is going to do on the right 
     */
    public void jump(boolean top,boolean right){
        int row = selected[1];
        int column = selected[2];
        int finalRow = ( top ) ? row - 2 : row + 2 ;
        int finalColumn = ( right ) ? column + 2 : column - 2  ;
        
        if ( ( 0<= finalRow &&  finalRow < size ) && ( 0<= finalColumn &&  finalColumn < size ) &&  boardOfPieces[finalRow][finalColumn] == null){
            int rowTemp = ( top ) ? row - 1 : row + 1 ,columnTemp = ( right ) ? column + 1 : column - 1  ;
            
            if ( ( boardOfPieces[rowTemp][columnTemp]!= null ) && (  boardOfPieces[rowTemp][columnTemp].getColor() != boardOfPieces[row][column].getColor()) ){
                selected[ 0] =0;
                add(  boardOfPieces[row][column].getColor() == "green", selected[3] == 1, finalRow +1,finalColumn+1);
                remove( new int[][] { {rowTemp + 1, columnTemp +1 }, { row + 1, column +1 }} );
                select(finalRow+1,finalColumn+1);
            }
            else{
                error(7);
                select(row+1,row+1);
            }
        }
        else{
            error(7);
            select(row+1,row+1);
        }
    }
    
    /**
     *@return information,a matrix of two array the pieces the first with the white pieces and the second with the black pieces.
     *Each piece will be a vector of three integers: 1 or 0 (whether it is dana or not) , the position in the rows and the position in the columns.
       */
    public int[][][] consult(){
        int information[][][]= new int[ 2 ][numberOfPieces][ 3 ];
        Piece currentPiece;
        int  position1 = 0, position2 = 0, type;
        
        for ( int row = 0; row < size ; row++  ){
            for ( int  column = 0; column < size ; column ++  ){
                currentPiece = boardOfPieces[ row ][ column ];
                if ( currentPiece != null ){
                    type = ( currentPiece.getType() ) ? 1: 0;
                    if ( currentPiece.getColor()  == "green" ){
                        information[ 0 ][ position1 ] = new int[]{ type , row + 1 , column + 1} ;
                        position1++;
                    }
                    else{
                        information[ 1 ][ position2 ] = new int[]{ type , row + 1 , column + 1} ;
                        position2++;
                    }
                }
            }
            
        }
        return information;
        
    }
    
    /**
     * given a character matrix, implement a piece matrix
     * @param matTable,character matrix to be drawn 
       */
    public void drawRead(char[][]matTable){
        int i,j;
        for(i=0 ; i<matTable.length;i++){
            for(j=0 ; j<matTable.length;j++){
                if (matTable[i][j]=='B'){
                    add(false,true,i+1,j+1);
                }
                else if (matTable[i][j]=='b'){
                    add(false,false,i+1,j+1);
                }
                else if (matTable[i][j]=='W'){
                    add(true,true,i+1,j+1);
                }
                else if (matTable[i][j]=='w'){
                    add(true,false,i+1,j+1);
                }
            }
        }
    }
    
    /***
     *method that takes care of modifying the char matrix in a String
     *@reuturn String, the matrix turned into a  String
     */
    public String changeToString(){
        lecture="";
        for( int i = 0; i < boardOfPieces.length ;i++){
            for(int j = 0; j < boardOfPieces.length ;j++){
                if(boardOfPieces[i][j]!=null){
                    if(boardOfPieces[i][j].getType() == true && boardOfPieces[i][j].getColor()=="green"){
                    lecture+="W";
                    }
                    else if(boardOfPieces[i][j].getType() == true && boardOfPieces[i][j].getColor()=="red"){
                    lecture+="B"; 
                    }
                    else if(boardOfPieces[i][j].getType() == false && boardOfPieces[i][j].getColor()=="green"){
                    lecture+="w"; 
                    }
                    else if(boardOfPieces[i][j].getType() == false && boardOfPieces[i][j].getColor()=="red"){
                    lecture+="b"; 
                    }
                }
                else{
                    if( (i+j) %2 != 0){
                    lecture+=".";
                    }
                    else if( (i+j) %2 ==0){
                    lecture+="-";
                    }
                }
            }
        }
        return lecture;
    }
    
    /**
       method that returns the checker matrix associated with the board
       @return Piece[][], char matrix of the board
       */
    public Piece[][] getBoard(){
        return boardOfPieces;
    }
    
    /**
       *method that removes all the checkers from a board
       */
    public void reset ( ){
        for ( int i = 0 ; i < size; i++){
            for ( int j = 0; j < size; j++){
                if ( boardOfPieces[ i ][ j ] != null ){
                     remove( i+1, j+1);
                }
            }
        }
            
    }
      
    /**
     * method that shows the exceptions when the program is executed and falls
     * @param typeError, integer that represent the associated error to be represented on the screen 
     * 
     */
    private void error( int  typeError ){
        switch ( typeError ){
            case 1:
            JOptionPane.showMessageDialog( null, "La Casilla solicitada ya se encuentra ocupado.",
                "El espacio solicitado ya se encuentra ocupado", JOptionPane.ERROR_MESSAGE ); 
            break;
            case 2:
            JOptionPane.showMessageDialog( null, "Solo de puede insertar en casillas de color negro. ",
                "Solo de puede insertar en casillas de color negro", JOptionPane.ERROR_MESSAGE ); 
            break;
            case 3:
            JOptionPane.showMessageDialog( null, "En la posicion ingresada no existe una ficha ",
                "En la posicion ingresada no existe una ficha ", JOptionPane.ERROR_MESSAGE ); 
            break;

            case 4 :
            JOptionPane.showMessageDialog( null, "debe ingreser una direccion valida  left/right",
                "debe ingreser una direccion valida left/right", JOptionPane.ERROR_MESSAGE ); 
            break;
            case 5 :
            JOptionPane.showMessageDialog( null, "No se logro mover la ficha, ya que existia otra",
                "No se logro mover la ficha, ya que existia otra", JOptionPane.ERROR_MESSAGE ); 
            break;
            case 6 :
            JOptionPane.showMessageDialog( null, "Se debe seleccionar primero una ficha",
                "Se debe seleccionar primero una ficha", JOptionPane.ERROR_MESSAGE ); 
            break;
            
            case 7 :
            JOptionPane.showMessageDialog( null, "No es posible matar",
                "No es posible matar", JOptionPane.ERROR_MESSAGE ); 
            break;

            default :
            JOptionPane.showMessageDialog( null, "La posición indicada se sale del rango del Tablero.",
                "La posición indicada se sale del rango del Tablero", JOptionPane.ERROR_MESSAGE ); 
            break;

        }
    }

        
}
