
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.io.*;

/**
 * The Board class will be the abstraction 
 * of the object "Chinese checkerboard"
 *
 * @author Iván Camilo Rincón Saavedra
 * @author Miguel Angel Fuquene Arias
 * 
 * @version 1.0 (04/02/2020)
 * @version 2.0 (05/02/2020)
 * @version 3.0 (06/02/2020)
 * @version 4.0 (15/02/2020)
 * @version 5.0 (17/02/2020)
 */
public class Board
{
    // instance variables 
    private static int numberOfPieces = 0;
    private int size;
    private int direction; // variable that modifies the location, according to the card that is entered the board 
    private static final  int sizeRec = 30 ;
    private int xPositionT;
    private int[] selected =   new int[]{ 0, -1, 1} ;


    private boolean typePiece = false;// type of the piece to add
    private Rectangle[][] board;// matrix representing the board
    private Piece piece;
    private Piece[][] boardOfPieces; // matrix representing the  pieces on the board
    private Rectangle casilla;
    private Piece arrow;
    private String color;
    private int val = 1;
    /**
     * Constructor for objects of class Board
     * @param you enter the size that the board will receive,
     * integer type called newSize
     */
    public Board( int newSize ){
        board = new Rectangle[newSize][newSize];
        boardOfPieces = new Piece[newSize][newSize];

        xPositionT = 0;
        size = newSize;  
    }

    
    /**
     * method that modifies the position from which the board is drawn
     * @param newPos ,enter the new start position of the board 
     */
    public void setXpos( int newPos ){
        this.xPositionT = newPos;
    }

    /**
     * method that get the position from which the board is drawn
     * @return the start drawing position of the board
     */
    public int getXpos( ){
        return this.xPositionT  ;
    }

    /**
     * method that verifies the indices are valid
     * @param row, integer type variable, which represents a index
     * @param column, integer type variable, which represents a index  
     * @return a boolean that represent whether or not it is valid 
     */
    private boolean checkPos( int row, int column ){
        boolean ok = true;
        
        if (  ( row <= 0 ) || ( column <= 0 ) || ( row > size ) || ( column > size ) ){
            error( 8 );
            ok = false;
        }
        else if ( ( row + column )%2 == 0 ){
            error( 2 );
            ok = false;
        }
        return ok;
    }

    /**
     * method that draw's the Board 
     */
    public void draw(){
        for ( int i = 0; i < this.size; i++ ){
            for ( int j = 0; j < this.size ; j++ ){

                if(  ( i + j ) % 2 == 0  ){ board[ i ][ j ] = null;}
                else if ( ( i + j ) % 2 != 0 ) {
                    casilla = new Rectangle();
                    
                    casilla.setXpos( sizeRec * j + xPositionT );
                    casilla.setYpos( i * sizeRec  );
                    casilla.makeVisible();
                    
                    board[ i ][ j ] =casilla;
                    
                }   
                boardOfPieces[ i ][ j ] = null;
            }   
        }
        arrow = new Piece("blue", true, ( size/2 ) * sizeRec + xPositionT, sizeRec * ( size + 1) );
        arrow.changeSize( 40,40);
        
    }
    
    /**
       *makes the arrow associated with the configuration table visible 
       */
    public void makeVisibleArrow( ){
       arrow.makeVisible(); 
    }
    
    /**
       *makes the arrow associated with the configuration table invisible 
       */
    public void makeInvisibleArrow( ){
       arrow.makeInvisible(); 
    }
    
    
    /**
     * method that places all pieces  
     */
    public void makeVisible(){
        for ( int i = 0; i < this.size  ; i++ ){
            for ( int j = 0; j < this.size; j++ ){ 
                if (  boardOfPieces[ i ][ j ] != null ){                
                    boardOfPieces[ i ][ j ].makeVisible();
                }
            }
        }

    }

    /**
     * method that places all  pieces  invisible
     */
    public void makeInvisible(){
        for ( int i = 0; i < this.size  ; i++ ){
            for ( int j = 0; j < this.size; j++ ){
                if (  boardOfPieces[ i ][ j ] != null ){
                    boardOfPieces[ i ][ j ].makeInvisible();
                }
            }
        }

    }
    
    /**
     * method that add's checkers from a board 
     * @param green, boolean that say if is green or not
     * @param row, integer type variable, which represents a index
     * @param column, integer type variable, which represents a index   
     */
    public void add( boolean green , boolean king, int row, int column ){
        int  x, xPos, yPos;
        Rectangle currentR;
       
        if ( checkPos( row, column ) ) {
            typePiece = king;
            this.color = ( green  ) ? "green": "red" ;
            
            row -= 1;
            column -=1 ;

            currentR = board[ row ][ column ];
            typePiece = ( (row == 0 && this.color == "red") || (  (row == size-1 && this.color == "green") ) ) ?true: king;
            
            direction = ( typePiece == true ) ? 2: 8 ;
            if ( boardOfPieces[ row ][ column ] != null ){ error( 1 ); }
            else{
                xPos =  currentR.getXpos()+ sizeRec / direction;
                yPos = currentR.getYpos() +sizeRec / 8;

                piece = new Piece(  this.color, typePiece, xPos ,  yPos);
                piece.makeVisible();

                boardOfPieces[ row ][ column ] = piece;
                numberOfPieces++;
            }
            typePiece = false;

        }
    }

    /**
     * method that add's checkers from a board 
     * @param green, boolean that say if is green or not
     *@param menL, matrix of integers which represent the positions of the chips to be added
     */
    public void add( boolean green ,int[][] menL ){
        int row;
        int[] current;

        for ( row = 0; row < menL.length; row++ ){
            current = menL[ row ];                
            add( green , false,  current[ 0 ], current[ 1 ] );
        } 
    }

    /**
     * method that removes checkers from a board 
     *@param pieces, matrix of integers, which represent the positions of the chips to be removed
     */
    public void remove( int[][] pieces ){
        int row, column, x;
        int[] currentP ;

        for ( x = 0; x < pieces.length; x++ ){
            currentP = pieces[ x ];

            row = currentP[ 0 ];
            column = currentP[ 1 ];

            remove(  row,  column );
        }
    }

    /**
     * method that removes checkers from a board 
     *@param row, integer type variable, which represents a index
     *@param column, integer type variable, which represents a index 
     */
    public void remove( int row, int column ) {
        int x, xPosF, yPosF;      
        if ( checkPos( row, column ) ){

            row -= 1;
            column -= 1;

            if ( boardOfPieces[ row ][ column ] != null  ){

                boardOfPieces[ row ][ column ].makeInvisible();
                boardOfPieces[ row ][ column ] = null;
                numberOfPieces--;

            }
            else{error( 3 );}
        }

            
    }

    /**
     * method that selects a piece and denotes a specific color 
     *@param row, integer type variable, which represents a index
     *@param column, integer type variable, which represents a index  
     */
    public void select(int row, int column){
        Piece currentPiece;
        
        if ( this.selected[0] == 0 ){
            if ( checkPos( row, column ) ){
                row -= 1;
                column -= 1;
                if ( boardOfPieces[ row ][ column ] != null ){
                    typePiece = boardOfPieces[ row ][ column ].getType();
                    this.color = boardOfPieces[ row ][ column ].getColor();
                    
                    boardOfPieces[ row ][ column ].changeColor(this.color,"yellow");          
                    this.selected = new int[]{ 1, row , column };
                }
                else{ error( 3 ); }
            }
        }
        else{
            makeVisible();
            this.selected = new int[]{0, -1, -1 };
        }
    }
    
    
    /**
     *method that moves a piece on the configuration board 
     *@param top, boolean that says if the piece moves up or down  
     *@param right,  boolean that says if the piece left or right  
     */
      
    public void shift( boolean top, boolean right  ){
        String leftOrright = ( right ) ? "right":"left";
        this.color = ( top ) ? "red":"green";
        move( leftOrright );        
    }
    
    /**
     * method that moves a piece in the direction it is assigned
     * @param notation, chain type variable that indicates which direction the part will take, it will take the left or right values
     */
    public void move( String notation ){
        int row, column, direccion ;
        boolean isLeft =  notation  == "left", isRight = notation  == "right" ;
        String color;
        
        Piece pieceTemp;
        notation = notation.toLowerCase();
        
        if ( selected[ 0 ] == 1 ){
            if (  isLeft || isRight ){
                color =  boardOfPieces[  selected[ 1 ]  ][  selected[ 2 ] ].getColor();
                this.direction  = ( isLeft ) ? - this.val: this.val;
                              
                row = ( this.color == "red" ) ?  selected[ 1 ] - this.val : selected[ 1 ]  + this.val ;
                column =  selected[ 2 ] + this.direction ;
                
                if ( ( row == 0 && color == "red" ) || ( row == size-1   && color == "green" ) ){
                    typePiece = true; 
                }
                
                if ( checkPos( row + 1, column + 1 ) ){
                    if ( boardOfPieces[ row ][ column ] == null ){
                        remove( selected[ 1 ] + 1  , selected[ 2 ] + 1);                        
                        add( color == "green",typePiece, row + 1 , column + 1);
                        
                        selected[ 0 ] = 0;
                    }
                    else{ error( 5 );}
                }
                this.direction  = 0;
            }
            else{ error( 4 ); }
        }
        else{ error(6); }
    }
    public void jump(boolean top,boolean right){
        int rowTemp , columnTemp;
        boolean colorAntiguo;
        boolean color;
        int row;
        int column;
        String leftOrright = ( right ) ? "right":"left";
        //this.color = ( top ) ? "red":"green";
        this.val = 2;
        rowTemp= ( top ) ? -1 : 1;
        columnTemp= ( right ) ? 1 : -1;
        row = selected[1] + rowTemp;
        column = selected[2] + columnTemp;
        if ( checkPos( row + 1, column + 1 ) ){
            if ( boardOfPieces[ row ][ column ] != null ){
                color= (boardOfPieces[selected[1]] [selected[2] ].getColor()=="red")? true: false;
                colorAntiguo = (boardOfPieces[  row  ][  column] .getColor()=="green")? true : false;
                if (color==colorAntiguo){
                    move( leftOrright );
                    remove( row + 1  , column + 1);
                }
                else{error(7);}
            }
            else{error(8);}
        }
        this.val =1;
    }
    
    
    /**
     *@return information,a matrix of two array the pieces the first with the white pieces and the second with the black pieces.
     *Each piece will be a vector of three integers: 1 or 0 (whether it is dana or not) , the position in the rows and the position in the columns.
       */
    public int[][][] consult(){
        int information[][][]= new int[2 ][numberOfPieces][ 3 ];
        Piece currentPiece;
        int  position1 = 0, position2 = 0, type;
        
        for ( int row = 0; row < size ; row++  ){
            for ( int  column = 0; column < size ; column ++  ){
                currentPiece = boardOfPieces[ row ][ column ];
                if ( currentPiece != null ){
                    type = ( currentPiece.getType() ) ? 1: 0;
                    if ( currentPiece.getColor()  == "green" ){
                        information[ 0 ][ position1 ] = new int[]{ type , row + 1 , column + 1} ;
                        position1++;
                    }
                    else{
                        information[ 1 ][ position2 ] = new int[]{ type , row + 1 , column + 1} ;
                        position2++;
                    }
                }
            }
            
        }
        return information;
        
    }
      
    /**
     * method that shows the exceptions when the program is executed and falls
     * @param typeError, integer that represent the associated error to be represented on the screen 
     * 
     */
    private void error( int  typeError ){
        switch ( typeError ){
            case 1:
            JOptionPane.showMessageDialog( null, "La Casilla solicitada ya se encuentra ocupado.",
                "El espacio solicitado ya se encuentra ocupado", JOptionPane.ERROR_MESSAGE ); 
            break;
            case 2:
            JOptionPane.showMessageDialog( null, "Solo de puede insertar en casillas de color negro. ",
                "Solo de puede insertar en casillas de color negro", JOptionPane.ERROR_MESSAGE ); 
            break;
            case 3:
            JOptionPane.showMessageDialog( null, "En la posicion ingresada no existe una ficha ",
                "En la posicion ingresada no existe una ficha ", JOptionPane.ERROR_MESSAGE ); 
            break;

            case 4 :
            JOptionPane.showMessageDialog( null, "debe ingreser una direccion valida  left/right",
                "debe ingreser una direccion valida left/right", JOptionPane.ERROR_MESSAGE ); 
            break;
            case 5 :
            JOptionPane.showMessageDialog( null, "No se logro mover la ficha, ya que existia otra",
                "No se logro mover la ficha, ya que existia otra", JOptionPane.ERROR_MESSAGE ); 
            break;
            case 6 :
            JOptionPane.showMessageDialog( null, "Se debe seleccionar primero una ficha",
                "Se debe seleccionar primero una ficha", JOptionPane.ERROR_MESSAGE ); 
            break;

            default :
            JOptionPane.showMessageDialog( null, "La posición indicada se sale del rango del Tablero.",
                "La posición indicada se sale del rango del Tablero", JOptionPane.ERROR_MESSAGE ); 
            break;

        }
    }

        
}
