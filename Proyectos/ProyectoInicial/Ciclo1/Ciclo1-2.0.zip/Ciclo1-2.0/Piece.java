

import java.util.ArrayList;

/**
     * The Board class will be the abstraction 
     * of the object "Chinese checkerboard"
     *
     * @author Iván Camilo Rincón Saavedra
     * @author Miguel Angel Fuquene Arias
     * 
     * @version 1.0 (04/02/2020)
     * @version 2.0 (05/02/2020)
     * @version 3.0 (06/02/2020)
     */
public class Piece{
    private int xPosition ;
    private int yPosition ;
    
    private boolean isVisible;
    private boolean type ;
    private boolean selected;
    
    private Circle men;
    private Triangle king;
    private String color;
    
    public Piece( String newColor, boolean newType , int newXPosition , int newYPosition  ){
        isVisible = false;
        xPosition = newXPosition;
        yPosition = newYPosition;
        color = newColor;
        type = newType;
        if ( type == false ){  men = new Circle( newColor,  newXPosition,  newYPosition );}
        
        else{ king = new Triangle( newColor,  newXPosition,  newYPosition );}
        
    }

    /**
     * method that defines the type of a piece token (king or men)
     *
     * @param newType, boolean var, if is true is a king otherwise is a men
     *
     */
    
    public void setType( boolean newType ){
        this.type = newType;

    }
    
    /**
     * method that return the type of a piece token (king or men)
     *
     * @return type , the type of the piece
     *
     */
    
    public boolean getType(){
        return this.type ;

    }
    
    
    /**
         * method that modifies the position from which the piece is drawn
         * @param newPos ,enter the new start position of the piece 
         */
    public void setXpos( int newPos ){
        this.xPosition = newPos;
        if ( this.type == false ) {
            men.setXpos( newPos );
            
        }
        else{
             king.setXpos( newPos );
        }
       
    }
    
    /**
         * method that get the xPosition from which the piece is drawn
         * @return xPosition, the start drawing xPosition of the piece
         */
    public int getXpos( ){
        return this.xPosition  ;
    }
    
    /**
         * method that modifies the position from which the piece is drawn
         * @param newPos ,enter the new start position of the piece 
         */
    public void setYpos( int newPos){
        this.yPosition = newPos;
        if ( this.type == false ) {
            men.setYpos( newPos );
            
        }
        else{
             king.setYpos( newPos );
        }
        
    }
    
    /**
         * method that get the yPosition from which the piece is drawn
         * @return yPosition, the start drawing yPosition of the piece
         */
    public int getYpos(  ){
        return this.yPosition  ;
    }
    
    
    /**
       * method that places  visible the piece
       * 
       */
    public void makeVisible(){
        isVisible = true ;
        if ( this.type == false ) {
            men.makeVisible(  );
            
        }
        else{
             king.makeVisible(  );
        }
        
    }
    
    
    /**
       * method that places  invisible the piece
       * 
       */
    public void makeInvisible(){
        isVisible = false ;
        
        if ( this.type == false ) {
            men.makeInvisible(  );
            
        }
        else{
             king.makeInvisible(  );
        }
    }
    
    /**
       *method that returns the current color of the piece
       *@return color, String that represents the color
       
       */
    public String getColor(){
        return this.color;
    }
      
    /**
       *method that defines temporaly a  color to one piece
       *@param oldColor, String , the final color of the piece 
       *@param newColor, String ,the temporaly color of the piece
       
       */
    public void changeColor( String oldColor,String newColor){

	if ( this.type == false ) {
            men.changeColor( newColor );
            men.setColor( oldColor );
            
        }
        else{
             king.changeColor( newColor  );
             king.setColor( oldColor );
        }
    }
    
    /**
       *method that change the size of a piece
       *@param newHeight, integer , the final heigth  of a piece 
       *@param newWidth, integer ,the final width of a piece
       
       */
    public void changeSize(int newHeight, int newWidth) {
		 king.changeSize(newHeight, newWidth);
    }
}