import java.util.ArrayList;
import java.lang.*; 

/**
 * w
     * The Board class will be the abstraction 
     * of the object "Chinese checkerboard"
     *
     * @author Iván Camilo Rincón Saavedra
     * @author Miguel Angel Fuquene Arias
     * 
     * @version 1.0 (04/02/2020)
     * @version 2.0 (05/02/2020)
     * @version 3.0 (06/02/2020)
     * @version 4.0 (17/02/2020)
     */
public class Checkers{
    // instance variables - replace the example below with your own
    private static boolean stop; 
    private int size;
    
    private Board configurationBoard;
    private Board gameBoard;
    private Board auxBoard;
    
    
    /**
     * Constructor for objects of class Checkers
     * @param with, the size of the board
     */
    public Checkers( int with  ){
        if ( with % 2 == 0){
            
            configurationBoard = new Board( with );
            gameBoard = new Board( with );
            
            size = with;
            
            configurationBoard.draw();
            configurationBoard.makeVisible();
            configurationBoard.makeVisibleArrow();
            
            gameBoard.setXpos( ( with + 3) * 30 );            
            gameBoard.draw();
            gameBoard.makeVisible(); 
            

            
        }
    }
    
    /**
      *method that selects a piece from a board
      *@param row, integer type variable, which represents a index
      *@param column, integer type variable, which represents a index 
      *
      */
    
    public void select( int row, int column ){
        configurationBoard.select(row , column);
    }
  
    /**
      * method that moves a piece in the direction it is assigned
      * @param notation, chain type variable that indicates which direction the part will take, it will take the left or right values
    */
    public void move( String notation ){
        configurationBoard.move( notation ) ;
    }
    public void jump(boolean top, boolean rigth){
        configurationBoard.jump( top, rigth );
    }
    /**
       * method that add's checkers from a board 
       * @param green, boolean that say if is green or not
       * @param row, integer type variable, which represents a index
       * @param column, integer type variable, which represents a index   
           */
    public void add(boolean green , boolean king, int row, int column ){
        configurationBoard.add( green ,king,row, column )  ;
    }
    
    /**
       method that moves a piece on the configuration board 
       @param top, boolean that says if the piece moves up or down  
       @param rigth,  boolean that says if the piece left or rigth  
       */
      
    public void shift( boolean top, boolean rigth  ){
        configurationBoard.shift( top, rigth );
    }
    
    
    /**
      * method that add's checkers from a board 
      * @param green, boolean that say if is green or not
      *@param menL, matrix of integers which represent the positions of the chips to be added
      */
    public void add( boolean green ,int[][] menL){
        configurationBoard.add( green, menL ); 
    }
    
    /**
      * method that removes checkers from a board 
      *@param row, integer type variable, which represents a index
      *@param column, integer type variable, which represents a index 
    */
    
    public void remove( int row, int column ){
        configurationBoard.remove( row, column );
    }
    
    
    /**
      * method that removes checkers from a board 
      *@param pieces, matrix of integers, which represent the positions of the chips to be removed
      */
    public void remove( int[][] pieces ){
        configurationBoard.remove( pieces );
    }
    
    /**
       method that exchanges the game board and configuration
       */
    public void swap(){
        configurationBoard.makeInvisibleArrow();
        auxBoard = configurationBoard;
        configurationBoard = gameBoard;
        gameBoard = auxBoard;
        
        
        configurationBoard.makeVisibleArrow();
    }
    
    /**
       *method that consults the pieces  that are in the different zones
       *1) Two vectors: the first with the information from the game board and the second with the configuration
       *2) Each board vector will have two vectors: the first with the white pieces and the second with the black pieces.
       *3) Each checker will be a vector of three integers: 1 or 0 (whether it is dana or not) , the position in the rows and the position in the columns.
       */
    public int[][][] consult( ){
        //terminar

        
        return  configurationBoard.consult();
        
    }
    
    
    /**
       * method that places all visible objects 
       * 
       */
    public void makeVisible(){
        configurationBoard.makeVisible();
    }
    
    
    /**
       * method that places all invisible objects 
       * 
       */
    public void makeInvisible(){
        configurationBoard.makeInvisible();
    }
    
    
    /**
       method that ends the execution
       
       */
    public void finish( ){
        System.exit( 0 );
        
    }
    /*
    public int ok( int row, int column ){
        return 1;
    }
    
  */  
}
