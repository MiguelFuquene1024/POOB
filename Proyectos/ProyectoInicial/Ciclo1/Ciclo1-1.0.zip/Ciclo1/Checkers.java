import java.util.ArrayList;
import java.lang.*; 

/**
     * The Board class will be the abstraction 
     * of the object "Chinese checkerboard"
     *
     * @author Iván Camilo Rincón Saavedra
     * @author Miguel Angel Fuquene Arias
     * 
     * @version 1.0 (04/02/2020)
     * @version 2.0 (05/02/2020)
     * @version 3.0 (06/02/2020)
     */
public class Checkers{
    // instance variables - replace the example below with your own
    private static boolean stop; 
    private int size;
    
    private int[][][]consultA;
    private Table tableJ;
    private Table tableC;
    private Table auxTable;
    
    
    /**
     * Constructor for objects of class Checkers
     * @param with, the size of the board
     */
    public Checkers( int with  ){
        if ( with % 2 == 0){
            
            tableC = new Table( with );
            tableJ = new Table( with );
            
            size = with;
            
            tableC.draw();
            tableC.makeVisible();
            
            tableJ.setXpos( ( with + 3) * 30 );            
            tableJ.draw();
            tableJ.makeVisible();            

            
        }
    }
    
    /**
      *method that selects a piece from a board
      *@param row, integer type variable, which represents a index
      *@param column, integer type variable, which represents a index 
      *
      */
    
    public void select( int row, int column ){
        tableJ.select(row , column);
    }
  
    /**
      * method that moves a piece in the direction it is assigned
      * @param notation, chain type variable that indicates which direction the part will take, it will take the left or right values
    */
    public void move( String notation ){
        tableJ.move( notation ) ;
    }
    
    /**
       * method that add's checkers from a board 
       * @param green, boolean that say if is green or not
       * @param row, integer type variable, which represents a index
       * @param column, integer type variable, which represents a index   
           */
    public void add(boolean green , boolean king, int row, int column ){
        tableC.add( green ,king,row, column )  ;
    }
    
    
    /**
      * method that add's checkers from a board 
      * @param green, boolean that say if is green or not
      *@param menL, matrix of integers which represent the positions of the chips to be added
      */
    public void add( boolean green ,int[][] menL){
        tableC.add( green, menL ); 
    }
    
    /**
      * method that removes checkers from a board 
      *@param row, integer type variable, which represents a index
      *@param column, integer type variable, which represents a index 
    */
    
    public void remove( int row, int column ){
        tableC.remove( row, column );
    }
    
    
    /**
      * method that removes checkers from a board 
      *@param pieces, matrix of integers, which represent the positions of the chips to be removed
      */
    public void remove( int[][] pieces ){
        tableC.remove( pieces );
    }
    
    /**
       method that exchanges the game board and configuration
       */
    public void swap(){
        auxTable = tableC;
        tableC = tableJ;
        tableJ = auxTable;
    }
    
    /**
       *method that consults the pieces  that are in the different zones
       */
    public int[][][] consult( ){
        int x, y ,z;
        ArrayList<Ficha> fichasC;
        ArrayList<Ficha> fichasJ;
        
        fichasC = tableC.getFichas();
        fichasJ = tableJ.getFichas();
        
        consultA = new int[2][fichasJ.size() + fichasC.size() ][2];
        
        
       
        
        
        for ( x = 0 ; x < 2; x++){
             
            if ( x == 0){
                for ( y = 0; y < fichasC.size();  y++){
                    consultA[x][y][1] = fichasC.get( y ).getXpos() ;
                    consultA[x][y][1] = fichasC.get( y ).getYpos();
                    
                }
            }
            else{
                for ( z = 0; z < fichasJ.size();  z++){
                    consultA[x][z][0] = fichasJ.get( z ).getXpos() ;
                    consultA[x][z][1] = fichasJ.get( z ).getYpos();
                }
            }
            
            
        }
        
        
        return consultA;
        
       
    }
    
    
    /**
       * method that places all visible objects 
       * 
       */
    public void makeVisible(){
        tableC.makeVisible();
    }
    
    
    /**
       * method that places all invisible objects 
       * 
       */
    public void makeInvisible(){
        tableC.makeInvisible();
    }
    
    
    /**
       method that ends the execution
       
       */
    public void finish( ){
        System.exit( 0 );
        
    }
    /*
    public int ok( int row, int column ){
        return 1;
    }
    
  */  
}
