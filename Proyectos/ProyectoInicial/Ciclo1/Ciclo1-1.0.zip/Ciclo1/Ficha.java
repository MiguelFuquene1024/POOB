

import java.util.ArrayList;

/**
     * The Board class will be the abstraction 
     * of the object "Chinese checkerboard"
     *
     * @author Iván Camilo Rincón Saavedra
     * @author Miguel Angel Fuquene Arias
     * 
     * @version 1.0 (04/02/2020)
     * @version 2.0 (05/02/2020)
     * @version 3.0 (06/02/2020)
     */
public class Ficha{
    private boolean isVisible;
    private int xPosition ;
    private int yPosition ;
    
    private boolean type ;
    private boolean selected;
    
    private Circle men;
    private Triangle king;
    
    private Circle circle;
    
    String color;
    
    public Ficha(){
        isVisible = false;
        xPosition = 0;
        yPosition = 0;
        color = "red";
        type = false;
        men = new Circle();
        king = new Triangle();
    }

    /**
     * method that defines the type of a piece token (king or men)
     *
     * @param newType, boolean var, if is true is a king otherwise is a men
     *
     */
    
    public void setType( boolean newType ){
        this.type = newType;

    }
    
    /**
     * method that return the type of a piece token (king or men)
     *
     * @return type , the type of the piece
     *
     */
    
    public boolean getType(){
        return this.type ;

    }
    
    
    /**
         * method that modifies the position from which the piece is drawn
         * @param newPos ,enter the new start position of the piece 
         */
    public void setXpos( int newPos ){
        this.xPosition = newPos;
        if ( this.type == false ) {
            men.setXpos( newPos );
            
        }
        else{
             king.setXpos( newPos );
        }
       
    }
    
    /**
         * method that get the xPosition from which the piece is drawn
         * @return xPosition, the start drawing xPosition of the piece
         */
    public int getXpos( ){
        return this.xPosition  ;
    }
    
    /**
         * method that modifies the position from which the piece is drawn
         * @param newPos ,enter the new start position of the piece 
         */
    public void setYpos( int newPos){
        this.yPosition = newPos;
        if ( this.type == false ) {
            men.setYpos( newPos );
            
        }
        else{
             king.setYpos( newPos );
        }
        
    }
    
    /**
         * method that get the yPosition from which the piece is drawn
         * @return yPosition, the start drawing yPosition of the piece
         */
    public int getYpos(  ){
        return this.yPosition  ;
    }
    
    
    /**
       * method that places  visible the piece
       * 
       */
    public void makeVisible(){
        isVisible = true ;
        if ( this.type == false ) {
            men.makeVisible(  );
            
        }
        else{
             king.makeVisible(  );
        }
        
    }
    
    
    /**
       * method that places  invisible the piece
       * 
       */
    public void makeInvisible(){
        isVisible = false ;
        
        if ( this.type == false ) {
            men.makeInvisible(  );
            
        }
        else{
             king.makeInvisible(  );
        }
    }
    
    /**
       *method that returns the current color of the piece
       *@return color, String that represents the color
       
       */
    public String getColor(){
        return this.color;
    }
    
    
    /**
       *method that defines the current color of the piece
       *@param newColor, the new color of the piece
       
       */
    public void setColor( String newColor ){
        this.color = newColor;
        if ( this.type == false ) {
            men.setColor( newColor );
            
        }
        else{
            king.setColor( newColor ) ;
        }
    }
    
    /**
       *method that defines temporaly a  color to one piece
       *@param oldColor, String , the final color of the piece 
       *@param newColor, String ,the temporaly color of the piece
       
       */
    public void changeColor( String oldColor,String newColor){

	if ( this.type == false ) {
            men.changeColor( newColor );
            men.setColor( oldColor );
            
        }
        else{
             king.changeColor( newColor  );
             king.setColor( oldColor ) ;
        }
    }
}