    import java.util.ArrayList;
    import javax.swing.JOptionPane;
    import java.io.*;
    
    /**
     * The Board class will be the abstraction 
     * of the object "Chinese checkerboard"
     *
     * @author Iván Camilo Rincón Saavedra
     * @author Miguel Angel Fuquene Arias
     * 
     * @version 1.0 (04/02/2020)
     * @version 2.0 (05/02/2020)
     * @version 3.0 (06/02/2020)
     */
    public class Table
    {
        // instance variables 
        private int size;
        private int direction; // variable that modifies the location, according to the card that is entered the board 
        private static final  int sizeRec = 30 ;
        private int xPositionT;
        private int fichaSeleccionada = -1;
        private int casillaX = -1;
        private int casillaY = -1;
        
        private boolean selected = false;
        private boolean tipoFicha = false;
        
        
        private ArrayList<ArrayList<Rectangle>>table;// matrix representing the board
        private ArrayList<Rectangle> fila;
    
        
        private Ficha ficha;
        private ArrayList<Ficha> fichas; // array representing the   
        private Rectangle casilla;
    
    
        /**
         * Constructor for objects of class Table
         * @param you enter the size that the board will receive,
         * integer type called newSize
         */
        public Table( int newSize ){
            
            table = new ArrayList();
            fichas = new ArrayList();
           
            xPositionT = 0;
            
            size =newSize;  
        }
        
        
        /**
         * method that modifies the position from which the board is drawn
         * @param newPos ,enter the new start position of the board 
         */
        public void setXpos( int newPos ){
            this.xPositionT = newPos;
        }
        
        
        /**
         * method that get the position from which the board is drawn
         * @return the start drawing position of the board
         */
        public int getXpos( ){
            return this.xPositionT  ;
        }
        
        
        /**
         * method that corrects positions for a index
         * @param row, integer type variable which represents an uncorrected index
         * @return the corrected index
         */
        
        public int finalXpos( int row ){
            return row - 1;
            
        }
        
        /**
         * method that corrects positions for a index
         * @param column, integer type variable which represents an uncorrected index
         * @return the corrected index
         */
        public int finalYpos( int column ){
            return ( column % 2 == 0 ) ? ( int ) column / 2 - 1 : ( int ) column / 2; 
            
        }
        
        /**
         * method that verifies the indices are valid
         * @param row, integer type variable, which represents a index
         * @param column, integer type variable, which represents a index  
         * @return a boolean that represent whether or not it is valid 
         */
        public boolean checkPos( int row, int column ){
            if ( ( ( row + column )%2 ==0 ) || ( row < 0 ) || ( column < 0 ) || ( row > size ) || ( column > size ) ){
                if ( ( row + column )%2 ==0 ){
                    error( 2 );
                    return false;

                }
                else{
                   error( 5 );
                   return false;
                }
                    
                    
            }
            return true;
        }
        
        /**
         * method that draw's the table 
         */
        public void draw(){
            int i,j, cont = 1 ;
            for ( i = 0; i < size; i++ ){
                fila = new ArrayList();
                j = 0;
                
                if ( i %2 != 0){ cont = 0; }
                else{ cont = 1;  }
            
                
                for ( j = 0; j < ( int ) size / 2; j++ ){
                    casilla = new Rectangle();
                    
                    casilla.setXpos( sizeRec * (j +cont ) + xPositionT );
                    casilla.setYpos( i * sizeRec  );
                    casilla.makeVisible();
        
                fila.add( casilla );
                    
                    cont ++;
                }
        
                table.add( fila );
        
            }
        }
    
        /**
         * method that places all visible objects 
         * 
         */
        
        public void makeVisible(){
            int i; 
            
            for ( i = 0; i < fichas.size() ; i++ ){
                fichas.get( i ).makeVisible();
            }
    
        }
        
        /**
         * method that places all invisible objects 
           */
        public void makeInvisible(){
            int i; 
            
            for ( i = 0; i < fichas.size() ; i++ ){
                fichas.get( i ).makeInvisible();
    
            }
    
        }
        
        
        /**
         * method that add's checkers from a board 
         * @param green, boolean that say if is green or not
         * @param row, integer type variable, which represents a index
         * @param column, integer type variable, which represents a index   
           */
        public void add( boolean green , boolean king, int row, int column ){
            
            tipoFicha = king;
            int [][] current =  {{row,column}};
            add( green ,current );
            tipoFicha = false;
        
        }
        
        /**
         * method that add's checkers from a board 
         * @param green, boolean that say if is green or not
         *@param menL, matrix of integers which represent the positions of the chips to be added
           */
        public void add( boolean green ,int[][] menL ){
            int row, column, x;
            int[] current ;
            Rectangle currentR;
            String color;
            
            for ( x = 0; x < menL.length ; x++){
                current = menL[ x ];
                direction = ( tipoFicha == true ) ? 0: 1 ;
                
                row = menL[ x ][ 0 ];
                column = menL[ x ][ 1 ];
                
                if ( checkPos( row, column ) ) {
                  
                    row = finalXpos( row );
                    column = finalYpos( column ) ;
                    
                    currentR = table.get( row ).get( column ); 
                    
                    if ( currentR.isBusy()   == true ){ error( 1 ); }
                    else{
                         
                        table.get( row ).get( column ).setBusy( true );
                        
                        ficha = new Ficha();
                        color = ( green == true ) ? "green" : "red" ;
                        
                        
                        ficha.setType( tipoFicha );
                        ficha.setColor( color );
                        
                        ficha.setXpos( currentR.getXpos()+ sizeRec / 2 -10 * direction );
                        ficha.setYpos( currentR.getYpos() + sizeRec / 2 -10 );
                        ficha.makeVisible();
                        
                        fichas.add( ficha );
                    }
                    
                    
                }    

            }
                
       
        }
        
        /**
         * method that looks for a piece on the board
         * @param xPosF,integer type variable, which represents a position of a checkers in  x
         *@param yPosF,integer type variable,  which represents a position of a checkers in  y
         * @return integer type variable, which represents the index of the checkers
           */
        public int find( int xPosF , int yPosF){
            int x;
            Ficha currentF ; //  ficha que se esta analizando
            for ( x = 0 ; x < fichas.size(); x++ ){
                    currentF = fichas.get( x );
                    
                    if ( ( currentF.getXpos() ==  xPosF || currentF.getXpos() ==  xPosF - 10 )&& ( currentF.getYpos() ==  yPosF ) ){
                        return x;
                    }
            }
            return 0;
        }
        
        /**
         * method that removes checkers from a board 
         *@param pieces, matrix of integers, which represent the positions of the chips to be removed
           */
        public void remove( int[][] pieces ){
            int row, column, x;
            int[] currentP ;
            
            for ( x = 0; x < pieces.length; x++ ){
                currentP = pieces[ x ];
                
                row = currentP[ 0 ];
                column = currentP[ 1 ];
                
                
                remove(  row,  column );
                
            }
        }
        
        /**
         * method that removes checkers from a board 
         *@param row, integer type variable, which represents a index
         *@param column, integer type variable, which represents a index 
           */
        public void remove( int row, int column ) {
            int x, xPosF, yPosF;      
            Rectangle currentR;
    
            if ( checkPos( row, column ) ){
                
                row = finalXpos( row );
                column = finalYpos( column ) ;
                
                if ( table.get( row ).get( column ).isBusy() == true  ){
                    
                    currentR  = table.get( row ).get( column );
                    
                    xPosF =  currentR.getXpos()+ sizeRec / 2 ;
                    yPosF = currentR.getYpos() + sizeRec / 2 -10;
                    
                    
                    table.get( row ).get( column ).setBusy( false );
                    
                    x = find( xPosF , yPosF);
                    fichas.get(x).makeInvisible();
                    fichas.remove( x );
                }
                else{error(3);}
            }
            
            
            
        }
        
        /**
         * method that selects a card and denotes a specific color 
         *@param row, integer type variable, which represents a index
         *@param column, integer type variable, which represents a index  
           */
        public void select(int row, int column){
            int position, xPosF, yPosF ;
            Rectangle currentR;
            String color ;
            
            
            if ( selected == false ){
                if ( checkPos( row, column ) ){
                casillaX = row;
                casillaY = column;
                
                row = finalXpos( row );
                column = finalYpos( column ) ;
                
                if ( table.get( row ).get( column ).isBusy() == true ){
                    
                    currentR =  table.get( row ).get( column );
                    
                    xPosF =  currentR.getXpos()+ sizeRec / 2 ;
                    yPosF = currentR.getYpos() + sizeRec / 2 -10;
                    
                    position = find( xPosF, yPosF );
                    
                    fichaSeleccionada = position ;
                    
                    tipoFicha = ficha.getType();
                    
                    color = fichas.get( position ).getColor();
             

                    fichas.get( position ).changeColor(color,"yellow");
                    selected = true;
                    
                }
                else{ error( 3 ); }
 
                }
            }
            else{
                makeVisible();
                selected = false;
            }
            
        }
        
        
        /**
         * method that moves a piece in the direction it is assigned
         * @param notation, chain type variable that indicates which direction the part will take, it will take the left or right values
           */
        public void move( String notation ){
            int row, column, direccion ;
            Ficha fichaTemp;
            String color;
            notation = notation.toLowerCase();
            
            
            boolean isIz =  notation  == "iz" ;
            boolean isDer = notation  == "der";
            
            if ( selected == true ){
                if (  isIz || isDer ){
                    fichaTemp = fichas.get( fichaSeleccionada );
                    direccion = 0;
                    color =  fichaTemp.getColor();
                    
                    if ( isIz ) { direccion = -1 ;}
                    
                    else if ( isDer ) { direccion = 1 ;}
                    
                    row = ( color == "red" ) ? casillaX - 1 : casillaX + 1;
                    column = casillaY + direccion ;
                    
                    if ( ( row == 1 && color == "red" ) || ( row == size   && color == "green" ) ){  tipoFicha = true; };
                    if ( ( column == 0 && isIz ) || ( column == size + 1  && isDer )  ){ error( 8 );}
                    
                    
                    else if ( checkPos( row, column ) ){
                        if ( !table.get( finalXpos(row) ).get( finalYpos(column) ).isBusy() ){
                            
                            remove( casillaX, casillaY );
                            add( fichaTemp.getColor() == "green",tipoFicha, row, column );
                            selected = false;
                        }
                    
                        else{ error( 5 );}
                    }
                }
                    
                else{ error( 4 ); }
            }
            else{ error(6); }
        }
        
        /**
         * method that returns pieces inserted into a board
         * @return fichas,board piece list 
           */
        
        public ArrayList<Ficha>  getFichas(){
            return fichas;
        }
        
        /**
         * method that shows the exceptions when the program is executed
         * @param typeError, integer that represent the associated error to be represented on the screen 
         * 
           */
        public void error( int  typeError ){
            switch ( typeError ){
                case 1:
                    JOptionPane.showMessageDialog( null, "La Casilla solicitada ya se encuentra ocupado.",
                            "El espacio solicitado ya se encuentra ocupado", JOptionPane.ERROR_MESSAGE ); 
                    break;
                case 2:
                    JOptionPane.showMessageDialog( null, "Solo de puede insertar en casillas de color negro. ",
                        "Solo de puede insertar en casillas de color negro", JOptionPane.ERROR_MESSAGE ); 
                    break;
                case 3:
                    JOptionPane.showMessageDialog( null, "En la posicion ingresada no existe una ficha ",
                        "Solo de puede insertar en casillas de color negro", JOptionPane.ERROR_MESSAGE ); 
                    break;
                
                case 4 :
                    JOptionPane.showMessageDialog( null, "debe ingreser una direccion valida iz/der",
                        "debe ingreser una direccion valida iz/der", JOptionPane.ERROR_MESSAGE ); 
                    break;
                case 5 :
                    JOptionPane.showMessageDialog( null, "No se logro mover la ficha, ya que existia otra",
                        "No se logro mover la ficha, ya que existia otra", JOptionPane.ERROR_MESSAGE ); 
                    break;
                case 6 :
                    JOptionPane.showMessageDialog( null, "Se debe seleccionar primero una ficha",
                        "Se debe seleccionar primero una ficha", JOptionPane.ERROR_MESSAGE ); 
                    break;
                    
                default :
                    JOptionPane.showMessageDialog( null, "La posición indicada se sale del rango del tablero.",
                        "La posición indicada se sale del rango del tablero", JOptionPane.ERROR_MESSAGE ); 
                    break;
                
            }
        }
        
        
        
        
}
