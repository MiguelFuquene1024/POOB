import java.util.ArrayList;

/**
     * The Board class will be the abstraction 
     * of the object "Chinese checkerboard"
     *
     * @author Iván Camilo Rincón Saavedra
     * @author Miguel Angel Fuquene Arias
     * 
     * @version 1.0 (04/02/2020)
     * @version 2.0 (05/02/2020)
     * @version 3.0 (06/02/2020)
     * @version 4.0 (03/03/2020)
     */
public  abstract class Piece  {
    protected int xPosition ;
    protected int yPosition ;
    protected String color;
    
    
    /**
     * Builder who creates a Piece 
     * @param newXpos, int coordinate at the x position that the Piece will take
     * @param newYpos, int coordinate at the y position that the Piece will take
     * @param newColor, String which represents the color that the Piece will take
     */
    public Piece( String newColor , int newXPosition , int newYPosition  ){
        xPosition = newXPosition;
        yPosition = newYPosition;
        color = newColor;

        
    }

    
    /**
     * method that set the position from which the board is drawn
     * @param newPos ,enter the new start position of the board 
     */
    public abstract void setXpos( int newXpos );
    
    /**
     * method that get the position from which the rectangle is drawn
     * @return xPosition , the x Position of one rectangle
     */
    public int getXpos( ){
        return this.xPosition  ;
    }
    
    /**
     * method that set the y position from which the rectangle is drawn
     *  @return yPosition , the y Position of one rectangle
     */
    public abstract  void setYpos( int newYpos );
    
    /**
     * method that get the y position from which the rectangle is drawn
     * @return yPosition ,return the y Position of one rectangle
     */
    
    public int getYpos( ){
        return this.yPosition  ;
    }
    
    /**
     * method that  Set the color. 
     * @param color the new color. Valid colors are "red", "yellow", "blue", "green",
     * "magenta" and "black".
     */
    public abstract void setColor( String newColor );

    /**
       * method that places  visible the piece
       * 
       */
    public abstract void  makeVisible();
    
    
    /**
       * method that places  invisible the piece
       * 
       */
    public abstract void makeInvisible();
    
    
    /**
       *method that returns the current color of the piece
       *@return color, String that represents the color
       
       */
    public String getColor(){
        return this.color;
    }
    
    
    /**
       *method thats save current color and set a new color to the piece
       *@param currentColor, String that represent the current color of the piece
       *@param newColor, String that represent the new color of  the piece
       */
    public abstract void temporalColor( String currentColor, String newColor  );
    
   
}