import Shape.*;
/**
 * Write a description of class King here.
 *
 * @author Iván Camilo Rincón Saavedra
 * @author Miguel Angel Fuquene Arias
 */
public class King extends Piece

{
    private Triangle king;
    
    /**
     * Constructor for objects of class King
     */
    public King( String newColor, int newXPosition , int newYPosition  )
    {
        
        super(  newColor ,  newXPosition ,  newYPosition  );
        king = new Triangle(   newXPosition ,  newYPosition ,  newColor);
        
    }
    /**
     * method that set the position from which the board is drawn
     * @param newPos ,enter the new start position of the board 
     */
    public  void setXpos( int newXpos ){
        king.setXpos( newXpos );
        
        
    }
    
    /**
     * method that set the y position from which the rectangle is drawn
     *  @return yPosition , the y Position of one rectangle
     */
    public   void setYpos( int newYpos ){
        king.setYpos( newYpos );
        
    }
    
    
    /**
     * method that  Set the color. 
     * @param color the new color. Valid colors are "red", "yellow", "blue", "green",
     * "magenta" and "black".
     */
    public  void setColor( String newColor ){
        king.setColor(  newColor );
        
    }
    /**
       * method that places  visible the piece
       * 
       */
    public  void  makeVisible(){
        king.makeVisible();
    }
    
    /**
       * method that places  invisible the piece
       * 
       */
    public  void makeInvisible(){
        king.makeInvisible();
    }
    
    
    /**
       *method thats save current color and set a new color to the piece
       *@param currentColor, String that represent the current color of the piece
       *@param newColor, String that represent the new color of  the piece
       */
    public void temporalColor( String currentColor, String newColor ){
        king.changeColor( newColor );
        king.setColor( currentColor );
        
    }
    
    /**
     * Change the size to the new size
     * @param newHeight the new height in pixels. newHeight must be >=0.
     * @param newWidht the new width in pixels. newWidht must be >=0.
     */
    public void changeSize(int newHeight, int newWidth) {
        king.changeSize( newHeight, newHeight);
    }
    
    
}
