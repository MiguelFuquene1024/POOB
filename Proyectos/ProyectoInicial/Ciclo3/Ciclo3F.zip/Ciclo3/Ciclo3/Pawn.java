import Shape.*;
/**
 * Write a description of class Pawn here.
 *
 *  @author Iván Camilo Rincón Saavedra
 * @author Miguel Angel Fuquene Arias
 */
public  class Pawn extends Piece
{
    private Circle pawn;
    /**
     * Constructor for objects of class Pawn
     */
    public Pawn(  String newColor , int newXPosition , int newYPosition )
    {
        super(   newColor ,  newXPosition ,  newYPosition );
        pawn = new Circle( newXPosition ,  newYPosition , newColor);
        
    }
    
   
    /**
     * method that set the position from which the board is drawn
     * @param newPos ,enter the new start position of the board 
     */
    public  void setXpos( int newPos ){
        pawn.setXpos( newPos );
        
        
    }
    
    /**
     * method that set the y position from which the rectangle is drawn
     *  @return yPosition , the y Position of one rectangle
     */
    public   void setYpos( int newPos ){
        pawn.setYpos( newPos );
        
    }
    
    
    /**
     * method that  Set the color. 
     * @param color the new color. Valid colors are "red", "yellow", "blue", "green",
     * "magenta" and "black".
     */
    public  void setColor( String newColor ){
        pawn.setColor(  newColor );
        
    }
    /**
       * method that places  visible the piece 
       */
    public  void  makeVisible(){
        pawn.makeVisible();
    }
    
    /**
       * method that places  invisible the piece
       */
    public  void makeInvisible(){
        pawn.makeInvisible();
    }
    
    /**
       *method thats save current color and set a new color to the piece
       *@param currentColor, String that represent the current color of the piece
       *@param newColor, String that represent the new color of  the piece
       */
    public void temporalColor( String currentColor, String newColor ){
        pawn.changeColor( newColor );
        pawn.setColor( currentColor );
        
    }
    
    
    


}
