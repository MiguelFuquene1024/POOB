
import javax.swing.JOptionPane;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class CheckersTest.
 *
 * @author Iván Camilo Rincón Saavedra
 * @author Miguel Angel Fuquene Arias
 * 
 * @version 1.0 (22/02/2020)
 */
public class CheckersTest
{
    /**
     * metodo para consultar las
       */
    @Test
    public void deberiaConsultar()
    {
        Checkers checkers1 = new Checkers(8);
        checkers1.add(true, new int[][]{{5,2},{5,4},{5,6}});
        checkers1.add(false, new int[][]{{6,1},{6,7}});
        checkers1.swap();
        assertEquals(new int[][][][]{   {   {  {0,6,1},{0,6,7}, {0,0,0}, {0,0,0},{0,0,0}   },  {  {0,5,2},{0,5,4},{0,5,6}, {0,0,0},{0,0,0}  } }   ,   {   {  {0,6,1},{0,6,7}, {0,0,0}, {0,0,0},{0,0,0}   },  {  {0,5,2},{0,5,4},{0,5,6}, {0,0,0},{0,0,0}  } }}, checkers1.consult());
        
    }
    
    

    @Test
    public void deberiaGuardarYrecuperar()
    {
        String board = "-.-.-.-..-.-.-.--.-.-.-..-.-.-.--w-w-w-..-.-.-.--.-.-.-..-.-.-.-" ;
        Checkers checkers1 = new Checkers(8);
        checkers1.add(true,  new int[][]{{5,2},{5,4},{5,6}});
        checkers1.save("configuracion");
        checkers1.remove( new int[][]{{5,2},{5,4},{5,6}});
        assertEquals(  board, checkers1.recover("configuracion"));
    }

    @Test
    public void deberiaEscribirYleer()
    {
        Checkers checkers1 = new Checkers(8);
        String board ="-.-.-.-..-.-.-.--.-.-.-..-.-.-.--w-w-w-.b-.-.-b--.-.-.-..-.-.-.-";
        checkers1.read(board);
        assertEquals(board, checkers1.write());
        
    }

    @Test
    public void deberiaSaltar() throws InterruptedException
    {
        Checkers checkers1 = new Checkers(8);
        String notation = "21x14x23";

        checkers1.add(true, new int[][]{{5,2},{5,4},{5,6}});
        checkers1.add(false, new int[][]{{6,7}});
        checkers1.add(false, true,6,1);
        
        checkers1.swap();
        checkers1.move( notation );
        assertEquals( checkers1.getBoard()[5][0] , null);
        assertEquals( checkers1.getBoard()[4][1] , null);
        assertFalse( checkers1.getBoard()[5][4].getClass() ==  null );
    }

    @Test
    public void deberiaFuncionarInvisible()
    {
        Checkers checkers1 = new Checkers(8);
        checkers1.add(true, new int[][] {{4,3},{3,4}});
        checkers1.add(false, new int[][] {{5,2},{5,4}});
        checkers1.makeInvisible();
        
        assertFalse( checkers1.getBoard()[3][2].getClass() ==  null );
    }

}







