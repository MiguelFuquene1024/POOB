package Checker;
import Shape.*;
/**
 * This class extends the class piece and create a new type of piece(king).
 *
 * @author Iván Camilo Rincón Saavedra
 * @author Miguel Angel Fuquene Arias
 */
public class King extends Piece
{
    /**
     * Is the class King constructor
     * @param board, is the board in which will add the new king
     * @param Shape, is the shape correspond to the type king of the token
     * @param f, is the row in which will add the new king
     * @param c, is the column in which will add the new king
     * @param type, is number that assign like type of the piece king
     */
    public King(Board board, Shapes shape, int f, int c, int type )
    {
        super(  board, shape, f, c, 1);
    }

}   
