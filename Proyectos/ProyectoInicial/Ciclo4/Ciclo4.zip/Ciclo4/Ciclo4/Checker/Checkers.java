package Checker;

import java.util.ArrayList;
import java.util.HashMap;
import java.lang.*; 
import javax.swing.JOptionPane;

/**
 * 
     * The Board class will be the abstraction 
     * of the object "Chinese checkerboard"
     *
     * @author Iván Camilo Rincón Saavedra
     * @author Miguel Angel Fuquene Arias
     * 
     * @version 1.0 (04/02/2020)
     * @version 2.0 (05/02/2020)
     * @version 3.0 (06/02/2020)
     * @version 4.0 (17/02/2020)
     * @version 5.0 (18/02/2020)
     * @version 6.0 (20/02/2020)
     * @version 7.0 (22/02/2020)
     * @version 8.0 (27/02/2020)
     * @version 9.0 (3/03/2020)
     */
public class Checkers{
    private boolean swaped = false; 
    private int posOfDraw;
    private int size;
    private HashMap<String, String> hashmapBoard = new HashMap<String,String> ();
    private ArrayList<Board> boards  = new ArrayList();
    /**
     * Constructor for objects of class Checkers
     * @param with, the size of the board
     */
    public Checkers( int width  ){
        
        if ( width % 2 == 0){
            posOfDraw = ( width + 3) * 30 ;
            boards.add( new Board( width, 0 ) );
            boards.add( new Board( width, posOfDraw ) );
            
            size = width;
            boards.get(0).makeVisibleArrow( 0 );
        }
        else{
            JOptionPane.showMessageDialog( null, "Debe ingresar un tablero de tamaño par",
                "Debe ingresar un tablero de tamaño par", JOptionPane.ERROR_MESSAGE );
        }
    }
    
    /**
     * method that returns the row and column given a board position
     * @param key, String  key representing the row and column in a hashmap
     * @return int[], that represents the row and column of the key that came in
     * 
       */
    public int[] getPosition( String key ){
        return boards.get(0).getPosition( key ) ;
    }

    /**
      *method that selects a piece from a board
      *@param row, integer type variable, which represents a index
      *@param column, integer type variable, which represents a index 
      *
      */
    
    public void select( int row, int column ){
        if ( !swaped ){
            boards.get(0).select(row , column);
        }
        else{
            boards.get(1).select(row , column);
        }
        
    }
  
    /**
      * method that moves a piece in the direction it is assigned
      * @param notation, chain type variable that indicates which direction the part will take, it will take the left or right values
    */
    public void move( String notation )   throws InterruptedException{
        if ( swaped ){
            boolean Bnotation = notation.contains("-" ) ;
            String [] movements = ( Bnotation ) ? notation.split("-"): notation.split("x") ;
            
            int[][] realMove =  new int[movements.length][2]; 
            for ( int x = 0 ; x < movements.length  ; x++ ) {
                realMove[ x ] = boards.get(1).getPosition( movements[ x ] ) ;
            }
            
            if ( Bnotation && movements.length > 2 ){
                JOptionPane.showMessageDialog( null, "Solo puede realizar un movimiento",
                "Solo puede realizar un movimiento", JOptionPane.ERROR_MESSAGE ); 
            }
            else{
                boards.get(1).move( realMove, ( Bnotation  ) ? false: true ) ;
            }
        }
        else{
            JOptionPane.showMessageDialog( null, "para usar este metodo debe estar en el tablero de juego",
                "para usar este metodo debe estar en el tablero de juego", JOptionPane.ERROR_MESSAGE ); 
        }
    }
    
    /**
      * method that moves a piece in with the best movement
    */
    public void move( )   throws InterruptedException{
        if ( swaped ){
            boards.get(1).move( );
        }
        else{
            boards.get(0).move(  );
        }

        
    }
    
    /**
     *  method that return the best movement of a piece
     *  @return String , thats represent the best move of a piece
       */
    public String moveString( ) throws InterruptedException{
        String string = "";
        if ( swaped ){
            string = boards.get(1).moveString();
            
            
            for ( int x = 0; x < 2; x++){
                swap();
            }
        }
        else{
            JOptionPane.showMessageDialog( null, "para usar este metodo debe estar en el tablero de configuracion",
                "para usar este metodo debe estar en el tablero de configuracion", JOptionPane.ERROR_MESSAGE ); 
        }
        return  ( string == "" )?string:string.substring(1);
        
        
    }
    
    /***
     * method that seeks to skip a token given its meaning
     *@param top, boolean that say if the jump is going to do on the top
     *@param rigth ,boolean that say if the jump is going to do on the right 
     */
    public void jump(boolean top, boolean rigth){
        if ( !swaped ){
            boards.get(0).jump( top, rigth,true );
        }
        else {
            JOptionPane.showMessageDialog( null, "para usar este metodo debe estar en el tablero de configuracion",
                "para usar este metodo debe estar en el tablero de configuracion", JOptionPane.ERROR_MESSAGE ); 
        }
        
    }
    
    public void addDiferentTypes( boolean green, int type , int row, int column ){
        if ( !swaped ){
            boards.get(0).addDiferentTypes( green, type,row, column );
        }
        else {
            JOptionPane.showMessageDialog( null, "para usar este metodo debe estar en el tablero de configuracion",
                "para usar este metodo debe estar en el tablero de configuracion", JOptionPane.ERROR_MESSAGE ); 
        }
    }
    
    /**
       * method that add's checkers from a board 
       * @param green, boolean that say if is green or not
       * @param row, integer type variable, which represents a index
       * @param column, integer type variable, which represents a index   
           */
    public void add(boolean green , boolean king, int row, int column ){
        if ( !swaped ){
            boards.get(0).add( green ,king,row, column );
        }
        else {
            JOptionPane.showMessageDialog( null, "para usar este metodo debe estar en el tablero de configuracion",
                "para usar este metodo debe estar en el tablero de configuracion", JOptionPane.ERROR_MESSAGE ); 
        }
    }
    
    
    /**
      * method that add's checkers from a board 
      * @param green, boolean that say if is green or not
      *@param menL, matrix of integers which represent the positions of the chips to be added
      */
    public void add( boolean green ,int[][] menL){
        if ( !swaped ){
            boards.get(0).add( green, menL ); 
        }
        else {
            JOptionPane.showMessageDialog( null, "para usar este metodo debe estar en el tablero de configuracion",
                "para usar este metodo debe estar en el tablero de configuracion", JOptionPane.ERROR_MESSAGE ); 
        }
    }

    
    /**
       method that moves a piece on the configuration board 
       @param top, boolean that says if the piece moves up or down  
       @param rigth,  boolean that says if the piece left or rigth  
       */
      
    public void shift( boolean top, boolean rigth  ){
        if ( !swaped ){
            boards.get(0).shift( top, rigth );
        }
        else {
            JOptionPane.showMessageDialog( null, "para usar este metodo debe estar en el tablero de configuracion",
                "para usar este metodo debe estar en el tablero de configuracion", JOptionPane.ERROR_MESSAGE ); 
        }
    }
    
    
    /**
      * method that removes checkers from a board 
      *@param row, integer type variable, which represents a index
      *@param column, integer type variable, which represents a index 
    */
    
    public void remove( int row, int column ){
        if ( !swaped ){
            boards.get(0).remove( row, column );
        }
        else {
            JOptionPane.showMessageDialog( null, "para usar este metodo debe estar en el tablero de configuracion",
                "para usar este metodo debe estar en el tablero de configuracion", JOptionPane.ERROR_MESSAGE ); 
        }
        
    }
    
    
    /**
      * method that removes checkers from a board 
      *@param pieces, matrix of integers, which represent the positions of the chips to be removed
      */
    public void remove( int[][] pieces ){
        if ( !swaped ){
            boards.get(0).remove( pieces );
        }
        else {
            JOptionPane.showMessageDialog( null, "para usar este metodo debe estar en el tablero de configuracion",
                "para usar este metodo debe estar en el tablero de configuracion", JOptionPane.ERROR_MESSAGE ); 
        }
        
    }
    
    /**
       method that exchanges the game board and configuration
       **/
    public void swap(){
        boards.get(0).makeInvisibleArrow();
        
        save( "Config" );
        swaped = !swaped;
        if ( swaped ){
            boards.get(0).makeVisibleArrow( posOfDraw );
            boards.get(1).reset();
            read( recover("Config") );
        }
        else{
            boards.get(0).makeVisibleArrow( 0 );
            boards.get(1).reset();
        }
        

    }
    
    /**
     * @param checkerboard, string that represents  a board
       *method that reads a string and represents it as a board
       */
    public void read(String checkerboard){
        int boardSize= (int) Math.sqrt(checkerboard.length()); 
        char [][] matTable = new char[boardSize][boardSize];
        int x=0;
        for( int i = 0; i< boardSize ; i++){
            for(int j =0 ; j< boardSize ; j++){
                matTable[i][j]=(char)checkerboard.charAt(x);
                x++;
            }
        }
        
        if ( swaped ){
            boards.get(1).reset();
            boards.get(1).drawRead(matTable);
        }
        
        else{
            boards.get(0).reset();
            boards.get(0).drawRead(matTable);
        }
    }
    
    /**
       *method that turns the current board into a chain
       */
    public String write(){
        return boards.get(0).changeToString();
    }
    
    /**
     * method that stores the char matrix as a String given a key
       */
    public void save(String name){
        hashmapBoard.put(name,write());
    }
    /**
     * method that retrieves a matrix given its key
       */
    public String recover(String name){
        return hashmapBoard.get(name);
    }
    /**
       *method that consults the pieces  that are in the different zones
       *1) Two vectors: the first with the information from the game board and the second with the configuration
       *2) Each board vector will have two vectors: the first with the white pieces and the second with the black pieces.
       *3) Each checker will be a vector of three integers: 1 or 0 (whether it is dana or not) , the position in the rows and the position in the columns.
       */
    public int[][][][] consult( ){
        return  new int [][][][]{boards.get(0).consult(),boards.get(1).consult()};
    }
    
    
    /**
       * method that places all pieces visible
       * 
       */
    public void makeVisible(){
        if ( swaped ){
            boards.get(1).makeVisible();
        }
        else{
            boards.get(0).makeVisible();
        }
        
    }
    
    
        /**
       * method that places all pieces invisible
       * 
       */
    public void makeInvisible(){
        if ( swaped ){
            boards.get(1).makeInvisible();
        }
        else{
            boards.get(0).makeInvisible();
        }
    }
    
    
    /**
       method that ends the execution
       
       */
    public void finish( ){
        System.exit( 0 );
    }
    /*
    public boolean ok( int row, int column ){
        return 1;
    }
    
  */
 
    /**
       method that returns the checker matrix associated with the board
       @return Piece[][], char matrix of the board
       */
     public Piece[][] getBoard( ){
            if ( swaped ){
                return boards.get(1).getBoard();
            }
            else{
                return boards.get(0).getBoard();
            }
    }
    
    /**
       *method that removes all the checkers from a board
       */
     public void reset(){
            if ( !swaped ){
                boards.get(0).reset();
            }
            else{
                JOptionPane.showMessageDialog( null, "para usar este metodo debe estar en el tablero de configuracion",
                "para usar este metodo debe estar en el tablero de configuracion", JOptionPane.ERROR_MESSAGE );
            }
            
    }
    
 
 

}
