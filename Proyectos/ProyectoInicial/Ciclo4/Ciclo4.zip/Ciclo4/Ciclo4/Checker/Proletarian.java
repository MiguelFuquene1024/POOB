package Checker;
import Shape.*;
/**
 * Write a description of class Powerful here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Proletarian extends Piece
{
    /**
     * Constructor for objects of class Proletarian
     */
    public Proletarian(   Board board, Shapes shape, int f, int c, int type)
    {
        super(  board, shape, f, c,3 );
        
    }
    /**
     * this method override the method move of the class piece
     * @param finalF, is the row where the token want to move
     * @param finalC, is the column where the token want to move
     */
    @Override
    public void move( int finalF, int finalC ){
        String color = getColor();
        if (  changeKing( finalF, finalC ) ){
            board.remove( f + 1  , c + 1);                         
        }
        else{
            super.moveTypes(finalF,finalC,3);
        };
    }
    /***
     * method that seeks to skip a token given its meaning
     *@param top, boolean that say if the jump is going to do on the top
     *@param rigth ,boolean that say if the jump is going to do on the right 
     */
    @Override 
    public void jump(boolean top,boolean right, boolean show, int r, int c){
        int finalRow = ( top ) ? r - 2 : r + 2 ,finalColumn = ( right ) ? c + 2 : c - 2  ;

        int rowTemp = ( top ) ? r - 1 : r + 1 ,columnTemp = ( right ) ? c + 1 : c - 1  ;
        if ( show ){
            checkPower(  rowTemp,  columnTemp,  r, c ); 
            if (  !changeKing( finalRow, finalColumn ) ){
                board.addDiferentTypes( getColor() == "green",3,finalRow + 1,finalColumn+1 );
            }
        }
    } 
    
    
    

}
