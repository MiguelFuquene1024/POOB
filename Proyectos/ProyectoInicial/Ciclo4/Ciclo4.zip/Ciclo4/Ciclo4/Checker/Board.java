package Checker;

import Shape.*;
import java.lang.Thread;
import java.util.*;
import java.lang.Math;
import javax.swing.JOptionPane;
import java.io.*;



/**
 * The Board class will be the abstraction 
 * of the object "Chinese checkerboard"
 *
 * @author Iván Camilo Rincón Saavedra
 * @author Miguel Angel Fuquene Arias
 * 
 * @version 1.0 (04/02/2020)
 * @version 2.0 (05/02/2020)
 * @version 3.0 (06/02/2020)
 * @version 4.0 (15/02/2020)
 * @version 5.0 (17/02/2020)
 * @version 6.0 (21/02/2020)
 * @version 7.0 (22/02/2020)
 * @version 8.0 (27/02/2020)
 * @version 9.0 (05/03/2020)
 * @version 10.0 (18/03/2020)
 */
public class Board
{
    public static  int size;
    private static final  int sizeRec = 30 ;
    private int numberOfPieces = 0;
    private int xPositionT;
    private String color;
    
    public int[] selected =   new int[]{ 0, -10, -10} ;
    public Rectangle[][] board;
    private Piece[][] boardOfPieces; 
    private Piece arrow;
    private HashMap< String ,int[] > position;
    
    /**
     * Constructor for objects of class Board
     * @param you enter the size that the board will receive,
     * integer type called newSize
     */
    public Board( int newSize, int posOfdraw ){
        board = new Rectangle[newSize][newSize];
        boardOfPieces = new Piece[newSize][newSize];
        position = new HashMap();

        xPositionT = posOfdraw;
        size = newSize; 
        draw();
    }

    public void setPiece( int f,  int c, Piece piece ){
        boardOfPieces[f][c] = piece;
    }
    
    public Piece getPiece( int f,  int c){
        return boardOfPieces[f][c];
    }

    /**
     * method that modifies the position from which the board is drawn
     * @param newPos ,enter the new start position of the board 
     */
    public void setXpos( int newPos ){
        xPositionT = newPos;
    }

    /**
     * method that get the position from which the board is drawn
     * @return the start drawing position of the board
     */
    public int getXpos( ){
        return xPositionT  ;
    }
    
    /**
     * method that returns the row and column given a board position
     * @param key, String  key representing the row and column in a hashmap
     * @return int[], that represents the row and column of the key that came in
     * 
       */
    public int[] getPosition( String key ){
        return position.get( key );
    }

    /**
     * method that verifies the indices are valid
     * @param row, integer type variable, which represents a index
     * @param column, integer type variable, which represents a index  
     * @return a boolean that represent whether or not it is valid 
     */
    public boolean checkPos( int row, int column, boolean busy, boolean message ){
        boolean ok = true;
        if (  ( row <= 0 ) || ( column <= 0 ) || ( row > size ) || ( column > size ) ){
            ok = false;
            if( message ){error(8);}
        }
        else if ( ( row + column )%2 == 0 ){
            ok = false;
            if( message ){error(2);}
        }
        else if ( boardOfPieces[row - 1][column - 1] == null && busy ){
            ok = false;
            if( message ){error(3);}
        }
        else if ( boardOfPieces[row - 1][column - 1] != null && !busy ){
            ok = false;
            if( message ){error(1);}
        }
        return ok;
    }
    
    /**
     * method that draw's the Board 
     */
    public void draw(){
        int pos = 1;
        for ( int i = 0; i < size; i++ ){
            for ( int j = 0; j < size ; j++ ){
                Rectangle casilla = new Rectangle(  sizeRec * j + xPositionT , sizeRec * i, "blue3" ); 
                
                if ( ( i + j ) % 2 != 0 ) {
                    casilla.setNum( new String().valueOf( pos ) );
                    board[ i ][ j ] =casilla;
                    position.put(  new String().valueOf( pos ), new int[]{i, j} );
                    pos++;
                }  
                else if ( ( i + j ) % 2 == 0 ){ 
                    board[ i ][ j ] = null;
                    casilla.changeColor("blue2");
                };
                casilla.makeVisible();
                boardOfPieces[ i ][ j ] = null;
            }   
        } 
    }
    
    
    /**
     * @param xPosition, int that represent's the initial position of draw of the board 
       *makes the arrow associated with the configuration table visible 
       */
    public void makeVisibleArrow( int xPosition) {
       arrow = new King(this,new Triangle( ( size/2 ) * sizeRec + xPosition , sizeRec * ( size + 1),"salmon"),-1,-1,1);
       arrow.makeVisible(); 
    }
    
    /**
       *makes the arrow associated with the configuration table invisible 
       */
    public void makeInvisibleArrow( ){
       arrow.makeInvisible(); 
    }
    
    
    /**
     * method that places all pieces  
     */
    public void makeVisible(){
        for ( int i = 0; i < size  ; i++ ){
            for ( int j = 0; j < size; j++ ){ 
                if (  boardOfPieces[ i ][ j ] != null ){                
                    boardOfPieces[ i ][ j ].makeVisible();
                }
            }
        }

    }

    /**
     * method that places all  pieces  invisible
     */
    public void makeInvisible(){
        for ( int i = 0; i < size  ; i++ ){
            for ( int j = 0; j < size; j++ ){
                if (  boardOfPieces[ i ][ j ] != null ){
                    boardOfPieces[ i ][ j ].makeInvisible();
                }
            }
        }
    }
    /**
     * This method is used to add different types of pieces to a board
     * @param green, boolean to indicate the color of the new token
     * @param type, indicate the type of the piece that want to add
     * @param row , indicate the row of the piece that want to add
     * @param column, indicate the column of the piece that want to add
     */
    public void addDiferentTypes( boolean green, int type , int row, int column ){
        Piece piece; 
        if ( checkPos( row, column,false, true ) ) {
            type =  (row-1 == 0 && "red".equals( color )) || (  (row == size-1 &&  "green".equals( color ) ) ) ?1:type;
            
            int xPos =  board[ row - 1 ][ column - 1 ].getXpos()+ sizeRec / ( ( type ==1 ) ? 2 : 8) ;
            int yPos = board[ row - 1 ][ column - 1 ] .getYpos() +sizeRec / 8;
            switch( type ){
                case 1: 
                    piece = new King(this,new Triangle( xPos , yPos,( green ) ?"green":"red"  ), row -1,column-1,1 );   
                    break;
                case 2:
                    piece = new Libertarian(this,new Circle( xPos , yPos,( green ) ?"green":"red"  ), row -1,column-1,2 );   
                    break;
                case 3:
                    piece = new Proletarian(this,new Circle( xPos , yPos,( green ) ?"green":"red"  ), row -1,column-1,3);   
                    break;
                case 4:
                    piece = new Lazy(this,new Circle( xPos , yPos,( green ) ?"green":"red"  ), row -1,column-1,4 );   
                    break;
                case 5:
                    piece = new Powerful(this,new Circle( xPos , yPos,( green ) ?"green":"red"  ), row -1,column-1,5 );   
                    break;
                case 6:
                    piece = new Pawn(this,new Circle( xPos , yPos,( green ) ?"green":"red"  ), row -1,column-1, 6 );   
                    break;
                case 7:
                    piece = new Hurried(this,new Circle( xPos , yPos,( green ) ?"green":"red"  ), row -1,column-1, 7 );   
                    break;
                default :
                    piece = new Suicide(this,new Circle( xPos , yPos,( green ) ?"green":"red"  ), row -1,column-1, 7 );   
                    break;
                    
            }
            piece.makeVisible();
            setPiece(row - 1, column - 1,piece);
            numberOfPieces++;
        }
        
    }
    
    /**
     * method that add's checkers from a board 
     * @param green, boolean that say if is green or not
     * @param row, integer type variable, which represents a index
     * @param column, integer type variable, which represents a index   
     */
    public void add( boolean green , boolean king, int row, int column ){
        Piece piece; boolean typePiece;
        if ( checkPos( row, column,false, true ) ) {
            typePiece =  (row == 0 && "red".equals( color )) || (  (row == size-1 &&  "green".equals( color ) ) ) ?true: king ;
            
            int xPos =  board[ row - 1 ][ column - 1 ].getXpos()+ sizeRec / ( ( king ) ? 2: 8 );
            int yPos = board[ row - 1 ][ column - 1 ] .getYpos() +sizeRec / 8;
            if  ( king ) {
                 piece = new King(this,new Triangle( xPos , yPos,( green ) ?"green":"red"  ), row -1,column-1,1 );
            }
            else{
                 piece = new Pawn(this,new Circle( xPos , yPos,( green ) ?"green":"red" ), row-1,column-1 , 6);
            }
            piece.makeVisible();
            boardOfPieces[ row - 1 ][ column - 1 ] = piece;
            numberOfPieces++;
        }
    }

    /**
     * method that add's checkers from a board 
     * @param green, boolean that say if is green or not
     *@param menL, matrix of integers which represent the positions of the chips to be added
     */
    public void add( boolean green ,int[][] menL ){
        for ( int row = 0; row < menL.length; row++ ){
            int[] current = menL[ row ];                
            add( green , false,  current[ 0 ], current[ 1 ] );
        } 
    }

    /**
     * method that removes checkers from a board 
     *@param pieces, matrix of integers, which represent the positions of the chips to be removed
     */
    public void remove( int[][] pieces ){
        for ( int  x = 0; x < pieces.length; x++ ){
            int[] currentP = pieces[ x ];
            int row = currentP[ 0 ],column = currentP[ 1 ];
            remove(  row,  column );
        }
    }

    /**
     * method that removes checkers from a board 
     *@param row, integer type variable, which represents a index
     *@param column, integer type variable, which represents a index 
     */
    public void remove( int row, int column ) {      
        if ( checkPos( row, column, true, true ) ){
            getPiece(row - 1,column - 1).makeInvisible();
            setPiece(row - 1, column - 1,null);
            numberOfPieces--;
        }

            
    }
    
    
    /**
     * method that selects a piece and denotes a specific color 
     *@param row, integer type variable, which represents a index
     *@param column, integer type variable, which represents a index  
     */
    public void select(int row, int column){
        Piece currentPiece; boolean typePiece;
        
        if ( selected[0] == 0 ){
            if ( checkPos( row, column, true, true ) ){
                typePiece = getPiece(row - 1, column - 1).getType() == 1;
                color = getPiece(row - 1,column - 1).getColor();                
                
                getPiece(row - 1,column - 1).temporalColor(color,"yellow"); 
                selected = new int[]{ 1, row - 1 , column - 1,(typePiece)?1:0 } ;
            }
        }
        else{
            makeVisible();
            selected = new int[]{0, -10, -10,-1 };
        }
    }
    
    /**
     *method that moves a piece on the configuration board 
     *@param top, boolean that says if the piece moves up or down  
     *@param right,  boolean that says if the piece left or right  
     */
      
    public void shift( boolean top, boolean right  ){
        color = ( top ) ? "red":"green";
        move( !right );        
    }
    
    /**
     * method that moves a piece in the direction it is assigned
     * @param notation, chain type variable that indicates which direction the part will take, it will take the left or right values
     */
    private  void move( boolean left ) {
        if ( selected[ 0 ] == 1 ){
            int row =  selected[ 1 ]  + (( "red".equals(this.color) ) ? - 1 : 1) ;
            int column =  selected[ 2 ] + (( left ) ? - 1: 1);
            
            if ( checkPos(  row + 1,  column + 1 ,false ,true ) ){
                getPiece( selected[1],selected[2]).move(   row,  column ); 
            }
            selected[ 0 ] = 0;
        }
        else{ error(6); }
    }
    
    
    
    /**
     * method that moves a piece in the direction it is assigned
     * @param notation, chain type variable that indicates which direction the part will take, it will take the left or right values
     */
    public void move(int[][]  movements, boolean jump )  throws InterruptedException{
        int row = movements[0][0] , column  = movements[0][1];
        for ( int x = 1 ; x < movements.length ; x++ ) {
            int row1 = movements[x][0], column1  = movements[x][1];
            boolean itsOK = ( getPiece(row1 , column1) == null ) && ( Math.abs(row - row1 ) == Math.abs( column - column1));
            
            select( row + 1, column + 1 ); Thread.sleep(500);
            if (itsOK && ( column1 == column + 1 | column1 == column - 1 ) && !jump ){
                 getPiece( row , column ).move(row1, column1  );
                 row = movements[x][0] ; column  = movements[x][1];
            }
            else if ( itsOK && ( column1 == column + 2 | column1 == column - 2 ) && jump  ){
                jump( ( row1 - row > 0 ) ? false: true , ( column1 - column > 0 ) ? true: false ,true);
                row = movements[x][0] ; column  = movements[x][1];
            }
            else{
                select( row + 1, column + 1 ); Thread.sleep(500);
            }
        }
    }

    /**
     * method thats said if a jump can do it
       */
    public boolean canJump (int row, int column, int row2, int column2, boolean top, boolean right){
        if ( checkPos( row2 + 1,column2 + 1, false,false ) ){
            int rowTemp = ( top ) ? row - 1 : row + 1 ,columnTemp = ( right ) ? column + 1 : column - 1  ;
            boolean valid = getPiece(row,column) !=null ;
            
            if ( valid && checkPos( rowTemp + 1,columnTemp + 1, true,false )
                &&  ( getPiece(rowTemp,columnTemp).getColor() != getPiece(row,column).getColor()) )
            {
                    return true;
            }
        }
        return false;
    }
       
    /**
     *  method that return the best movement of a piece
     *  @return String , thats represent the best move of a piece
       */
    public String moveString(  ) throws InterruptedException{
        if ( selected[0] == 1){
            int row= selected[1], column = selected[2];
            return getPiece(row,column).moveString(  );
        }
        return "";
    }
    
    /**
      * method that moves a piece in with the best movement
    */
    public void move()   throws InterruptedException{
        HashMap< String, Integer> dict = new HashMap(); 
        if ( selected[0] == 1 ){
            int row= selected[1], column = selected[2];
            getPiece( row, column ).move();
        }
        else{
            error( 6 );
        }
    }
    

    /***
     * method that seeks to skip a token given its meaning
     *@param top, boolean that say if the jump is going to do on the top
     *@param rigth ,boolean that say if the jump is going to do on the right 
     */
    public void jump(boolean top,boolean right, boolean show){
        int row = selected[1], column = selected[2];
        int finalRow = ( top ) ? row - 2 : row + 2 ;
        int finalColumn = ( right ) ? column + 2 : column - 2  ;

        if (   canJump ( row,  column,  finalRow, finalColumn, top, right ) ){
            getPiece( row , column).jump( top, right , show, row, column);
            select( row,column);
            
        }
        else{
            if ( show ){
                error(7);
            }
        }
    }
    
    /**
     *@return information,a matrix of two array the pieces the first with the white pieces and the second with the black pieces.
     *Each piece will be a vector of three integers: 1 or 0 (whether it is dana or not) , the position in the rows and the position in the columns.
       */
    public int[][][] consult(){
        int information[][][]= new int[ 2 ][numberOfPieces][ 3 ];
        Piece currentPiece;
        int  position1 = 0, position2 = 0, type;
        
        for ( int row = 0; row < size ; row++  ){
            for ( int  column = 0; column < size ; column ++  ){
                currentPiece = getPiece( row,column) ;
                if ( currentPiece != null ){
                    type = ( currentPiece instanceof King) ? 1 : 0;
                    
                    if ( "green".equals( currentPiece.getColor() )   ){
                        information[ 0 ][ position1 ] = new int[]{ type , row + 1 , column + 1} ;
                        position1++;
                    }
                    else{
                        information[ 1 ][ position2 ] = new int[]{ type , row + 1 , column + 1} ;
                        position2++;
                    }
                }
            } 
        }
        return information;
        
    }
    
    /**
     * given a character matrix, implement a piece matrix
     * @param matTable,character matrix to be drawn 
       */
    public void drawRead(char[][]matTable){
        int i,j;
        for(i=0 ; i<matTable.length;i++){
            for(j=0 ; j<matTable.length;j++){
                if (matTable[i][j]=='B'){
                    add(false,true,i+1,j+1);
                }
                else if (matTable[i][j]=='b'){
                    add(false,false,i+1,j+1);
                }
                else if (matTable[i][j]=='W'){
                    add(true,true,i+1,j+1);
                }
                else if (matTable[i][j]=='w'){
                    add(true,false,i+1,j+1);
                }
            }
        }
    }
    
    /***
     *method that takes care of modifying the char matrix in a String
     *@reuturn String, the matrix turned into a  String
     */
    public String changeToString(){
        String lecture="";
        for( int i = 0; i < boardOfPieces.length ;i++){
            for(int j = 0; j < boardOfPieces.length ;j++){
                if(boardOfPieces[i][j]!=null){
                    boolean type = (( boardOfPieces[i][j]) instanceof King) ? true : false ;
                    
                    if(type  &&  "green".equals( boardOfPieces[i][j].getColor() ) ){
                    lecture+="W";
                    }
                    else if(type && "red".equals( boardOfPieces[i][j].getColor() ) ){
                    lecture+="B"; 
                    }
                    else if( !type  && "green".equals( boardOfPieces[i][j].getColor() )){
                    lecture+="w"; 
                    }
                    else if(!type && "red".equals( boardOfPieces[i][j].getColor() )){
                    lecture+="b"; 
                    }
                }
                else{
                    if( (i+j) %2 != 0){
                    lecture+=".";
                    }
                    else if( (i+j) %2 ==0){
                    lecture+="-";
                    }
                }
            }
        }
        return lecture;
    }
    
    /**
       method that returns the checker matrix associated with the board
       @return Piece[][], char matrix of the board
       */
    public Piece[][] getBoard(){
        return boardOfPieces;
    }
    
    /**
       *method that removes all the checkers from a board
       */
    public void reset ( ){
        for ( int i = 0 ; i < size; i++){
            for ( int j = 0; j < size; j++){
                if ( boardOfPieces[ i ][ j ] != null ){
                     remove( i+1, j+1);
                }
            }
        }
            
    }
      
    /**
     * method that shows the exceptions when the program is executed and falls
     * @param typeError, integer that represent the associated error to be represented on the screen 
     * 
     */
    private void error( int  typeError ){
        switch ( typeError ){
            case 1:
            JOptionPane.showMessageDialog( null, "La Casilla solicitada ya se encuentra ocupado.",
                "El espacio solicitado ya se encuentra ocupado", JOptionPane.ERROR_MESSAGE ); 
            break;
            case 2:
            JOptionPane.showMessageDialog( null, "Solo de puede insertar en casillas de color negro. ",
                "Solo de puede insertar en casillas de color negro", JOptionPane.ERROR_MESSAGE ); 
            break;
            case 3:
            JOptionPane.showMessageDialog( null, "En la posicion ingresada no existe una ficha ",
                "En la posicion ingresada no existe una ficha ", JOptionPane.ERROR_MESSAGE ); 
            break;
            
            case 5 :
            JOptionPane.showMessageDialog( null, "No se logro mover la ficha, ya que existia otra",
                "No se logro mover la ficha, ya que existia otra", JOptionPane.ERROR_MESSAGE ); 
            break;
            
            case 6 :
            JOptionPane.showMessageDialog( null, "Se debe seleccionar primero una ficha",
                "Se debe seleccionar primero una ficha", JOptionPane.ERROR_MESSAGE ); 
            break;
            
            case 7 :
            JOptionPane.showMessageDialog( null, "No es posible matar",
                "No es posible matar", JOptionPane.ERROR_MESSAGE ); 
            break;

            default :
            JOptionPane.showMessageDialog( null, "La posición indicada se sale del rango del Tablero.",
                "La posición indicada se sale del rango del Tablero", JOptionPane.ERROR_MESSAGE ); 
            break;
        }
    }

        
}
