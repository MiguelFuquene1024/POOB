package Shape;
import java.awt.*;

/**
     * The Board class will be the abstraction 
     * of the object "Chinese checkerboard"
     *
     * @author Iván Camilo Rincón Saavedra
     * @author Miguel Angel Fuquene Arias
     * 
     * @version 1.0 (04/02/2020)
     * @version 2.0 (05/02/2020)
     * @version 3.0 (06/02/2020)
     * @version 4.0 (03/03/2020)
     */


 
public class Rectangle extends Shapes{
 
    private int height;
    private int width;
    private String num;
    
    
    /**
     * Create a new rectangle at default position with default color.
     */
    public  Rectangle( int newXpos, int newYpos, String newColor  ){
        super( newXpos,  newYpos,  newColor);
        height = 30;
        width = 30;
    }
    
    /**
     * Create a new number associated on one rectangle
     * @param, a int that represent a number associated on one rectangle
     */
    public void setNum( String value ){
        num = value;
    }
    
    /**
     * @return String , that represent a number associated on one rectangle
     */
    public String getNum(){
        return num ;
    }

    /**
     * Change the size to the new size
     * @param newHeight the new height in pixels. newHeight must be >=0.
     * @param newWidht the new width in pixels. newWidth must be >=0.
     */
    public void changeSize(int newHeight, int newWidth) {
        erase();
        height = newHeight;
        width = newWidth;
        draw();
    }
    

    /**
     * Draw the rectangle with current specifications on screen.
     */

    public void draw() {
        if(isVisible) {
            canv().draw(this, color,
            new java.awt.Rectangle(xPosition, yPosition, width, height));
        }
    }

}

