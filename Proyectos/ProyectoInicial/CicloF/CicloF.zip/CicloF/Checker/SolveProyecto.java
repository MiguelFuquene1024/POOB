
package Checker;
import java.util.Hashtable;


/**
         * version en string 
        for(int x=0;x<8;x++) {
            for(int a=0;a<2;a++){
                for(int y=0;y<8;y++) {
                    if(a==0) {
                System.out.print(matriz[x][y]);
                    }
                    else {
                System.out.print(matriz2[x][y]);
                    }
            }
            System.out.print(" ");
            }
            System.out.println();
        }**/


/**
 * Write a description of class SolveProyecto here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SolveProyecto
{
    private int x;
    private static Hashtable<String, int []> dic = new Hashtable<String, int[]>();
    private static String[] rta; 
    /**
     * Constructor for objects of class SolveProyecto
     */
    public SolveProyecto()
    {
        x = 0;
        rta = new String[] {"",""};
    }
    public static String[] solve(String player,String[]moves) {

    String player2=(player=="W")?"B":"W";

    String[][] matriz =crear(8);
    String[][] matriz2 =crear(8);
    for(int i=0;i<moves.length;i++) {

            boolean notation =moves[i].contains("-");
            String[] mov= ( notation ) ? moves[i].split("-"): moves[i].split("x");
            int [] mov2= new int [mov.length];
            for(int x=0;x<mov.length;x++) {
                mov2[x] = Integer.parseUnsignedInt(mov[x]);
            }
            if(notation) {
                String firstMove =mov[0] ,finalMove =mov[1];
                if(i%2==1) {
                    matriz[ dic.get(firstMove)[0] ][ dic.get(firstMove)[1] ] = player2;
                }
                else {
                    matriz[ dic.get(firstMove)[0] ][ dic.get(firstMove)[1] ] = player;
                }
                matriz2[ dic.get(finalMove)[0] ][ dic.get(finalMove)[1] ] = matriz[ dic.get(firstMove)[0] ][ dic.get(firstMove)[1]];        
            }
            else {
                for ( int x=0;x<mov.length-1;x++ ) {
                    String firstMove =mov[x] ;
                    if(i%2==0) {
                    if(matriz[dic.get(firstMove)[0]][dic.get(firstMove)[1]]==".") {
                        matriz[dic.get(firstMove)[0]][dic.get(firstMove)[1]] =(x==0)? player:".";
                        matriz2[dic.get(firstMove)[0]][dic.get(firstMove)[1]] =(x==0)?player:matriz2[dic.get(firstMove)[0]][dic.get(firstMove)[1]]; 
                    }
                    }
                    else{
                    if(matriz[dic.get(firstMove)[0]][dic.get(firstMove)[1]]==".") {
                        matriz[dic.get(firstMove)[0]][dic.get(firstMove)[1]] =(x==0)? player2:".";
                        matriz2[dic.get(firstMove)[0]][dic.get(firstMove)[1]] =(x==0)?player2:matriz2[dic.get(firstMove)[0]][dic.get(firstMove)[1]];
                    }
                    }
                    int a=Integer.parseUnsignedInt(firstMove);
                    if( dic.get(firstMove)[0] % 2 == 0) {
                    String finalMove =mov[x+1];
                    int b=Integer.parseUnsignedInt(finalMove);
                    matriz2[ dic.get(finalMove)[0] ][ dic.get(finalMove)[1] ] = matriz2[ dic.get(firstMove)[0] ][ dic.get(firstMove)[1] ];  
                    matriz2[ dic.get(firstMove)[0] ][ dic.get(firstMove)[1] ] = ".";
                    int minum=Math.min(a, b);
                    int absolute=(int)Math.abs(a-b)/2+1;
                    String suma=(new Integer(minum+absolute)).toString();
                    if(matriz2[dic.get(suma)[0]][dic.get(suma)[1]]==".") {
                        matriz[ dic.get(suma)[0] ][ dic.get(suma)[1] ]=(i%2==0)?player2:player;
                    }
                    matriz2[dic.get(suma)[0]][dic.get(suma)[1]]=".";            
                    }
                    else {
                String finalMove =mov[x+1];
                int b=Integer.parseUnsignedInt(finalMove);
                matriz2[ dic.get(finalMove)[0] ][ dic.get(finalMove)[1] ] = matriz2[ dic.get(firstMove)[0] ][ dic.get(firstMove)[1] ];
                matriz2[ dic.get(firstMove)[0] ][ dic.get(firstMove)[1] ] = ".";
                int minum=Math.min(a, b);
                int absolute=(int)Math.abs(a-b)/2;
                String suma=(new Integer(minum+absolute)).toString();
                if(matriz2[dic.get(suma)[0]][dic.get(suma)[1]]==".") {
                    matriz[ dic.get(suma)[0] ][ dic.get(suma)[1] ]=(i%2==0)?player2:player;
                }
                matriz2[dic.get(suma)[0]][dic.get(suma)[1]]=".";
                    }
                }
            }
        }

        for(int x=0;x<8;x++) {
            for(int a=0;a<2;a++){
                for(int y=0;y<8;y++) {
                    if(a==0) {
                        rta[0]+=matriz[x][y];
                    }
                    else {
                        rta[1]+=matriz2[x][y];
                    }
                }
            }
        }
        return rta;
    }   
    public static String[][] crear(int n){
        Integer cont=1;
        String[][] matriz= new String [n][n];
        for (int i=0;i<n;i++) {
            for(int j=0; j<n;j++) {
                matriz[i][j]=((i+j)%2==1)?".":"-";
            if((i+j)%2==1) {
                dic.put(cont.toString(),new int [] {i,j});
                cont++;
            }
            }
        }
        return matriz;
    }
}
