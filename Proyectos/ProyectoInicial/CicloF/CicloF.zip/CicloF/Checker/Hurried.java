package Checker;

 
import Shape.*;
/**
 * This class extends the class piece and create a new type of piece(Hurried).
 * 
 * @author Miguel Angel Fuquene
 * @author Ivan Camilo Rincon
 * @version 1.0
 */
public class Hurried extends Piece
{
    int times = 0;
    /**
     * Constructor for objects of class Powerful
     */
    
    public Hurried(   Board board, Shapes shape, int f, int c, int type )
    {
        super(  board, shape, f, c,7 );
    }
    /**
     * this method override the method move of the class piece
     * @param finalF, is the row where the token want to move
     * @param finalC, is the column where the token want to move
     */
    @Override 
    public  void move(  int finalF, int finalC ){
        super.moveTypes( finalF,finalC, 7);
    }
    
    @Override 
    /***
     * method that seeks to skip a token given its meaning
     *@param top, boolean that say if the jump is going to do on the top
     *@param rigth ,boolean that say if the jump is going to do on the right 
     */
    public void jump(boolean top,boolean right, boolean show, int r, int c)  {
        int row = ( top ) ? r - 2 : r + 2 , column = ( right ) ?   c + 2 :  c - 2  ;
        int rowTemp = ( top ) ? r - 1 : r + 1 ,columnTemp = ( right ) ? c + 1 : c - 1  ;
        checkPower(  rowTemp,  columnTemp,  r, c );
        
        board.addDiferentTypes( getColor() == "green",7,row + 1,column+1 );
        
        if (  times <1 && board.canJump( row, column, row - 2  , column + 2 ,true,true ) ) {
            board.select( r + 1, c + 1);
            board.select( row + 1 ,column + 1 );
            times++;
            updateFC( row, column);
            jump( true, true, true, row, column);
            
        }
        else if (  times <1 && board.canJump( row, column, row + 2  , column + 2 ,false,true ) ) {
            board.select( r + 1, c + 1);
            board.select( row + 1 ,column + 1 );
            times++;
            updateFC( row, column);
            jump( false, true, true, row, column );
        }
        else if (  times <1 && board.canJump( row, column, row + 2  , column - 2 ,false,false ) ) {
            board.select( r + 1, c + 1);
            board.select( row + 1 ,column + 1 );
            times++;
            updateFC( row, column);
            jump( false, false, true, row, column );
        }
        else if (  times <1 && board.canJump( row, column, row - 2  , column - 2 ,true,false ) ) {
            board.select( r + 1, c + 1);
            board.select( row + 1 ,column + 1 );
            times++;
            updateFC( row, column);
            jump( true, false, true, row, column );
        }
        times = 0;
    }


}