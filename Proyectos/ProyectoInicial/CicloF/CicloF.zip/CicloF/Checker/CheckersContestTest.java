package Checker;



import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class CheckersContestTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class CheckersContestTest
{
    /**
     * Default constructor for test class CheckersContestTest
     */
    public CheckersContestTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void deberiaSimularLentoCaso1() throws InterruptedException
    {
        Checker.CheckersContest checkers1 = new Checker.CheckersContest();
        checkers1.simulate("W", new String[]{"21-17","13x22x31x24","19x28"}, true);
    }
     @Test
    public void deberiaSimularRapidoCaso1() throws InterruptedException
    {
        Checker.CheckersContest checkers1 = new Checker.CheckersContest();
        checkers1.simulate("W", new String[]{"21-17","13x22x31x24","19x28"}, false);
    }
    
     @Test
    public void deberiaSimularLentoCaso2() throws InterruptedException
    {
        Checker.CheckersContest checkers1 = new Checker.CheckersContest();
        checkers1.simulate("B", new String[]{"2-7","9x2","32-27","2x11x18","5-9"}, true);
    }
     @Test
    public void deberiaSimularRapidoCaso2() throws InterruptedException
    {
        Checker.CheckersContest checkers1 = new Checker.CheckersContest();
        checkers1.simulate("B", new String[]{"2-7","9x2","32-27","2x11x18","5-9"}, false);
    }
}

