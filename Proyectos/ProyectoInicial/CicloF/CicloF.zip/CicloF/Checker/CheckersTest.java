package Checker;

 

import javax.swing.JOptionPane;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class CheckersTest.
 *
 * @author Iván Camilo Rincón Saavedra
 * @author Miguel Angel Fuquene Arias
 * 
 * @version 1.0 (22/02/2020)
 */
public class CheckersTest
{
    @Test
    public void deberiaGuardarYrecuperar()
    {
        String board = "-.-.-.-..-.-.-.--.-.-.-..-.-.-.--w-w-w-..-.-.-.--.-.-.-..-.-.-.-" ;
        Checkers checkers1 = new Checkers(8);
        checkers1.add(true,  new int[][]{{5,2},{5,4},{5,6}});
        checkers1.save("configuracion");
        checkers1.reset();
        assertEquals(  board, checkers1.recover("configuracion"));
    }

    @Test
    public void deberiaEscribirYleer()
    {
        Checkers checkers1 = new Checkers(8);
        String board ="-.-.-.-..-.-.-.--.-.-.-..-.-.-.--w-w-w-.b-.-.-b--.-.-.-..-.-.-.-";
        checkers1.read(board);
        assertEquals(board, checkers1.write());
        checkers1.reset();
        
    }

    @Test
    public void deberiaSaltar() throws InterruptedException
    {
        Checkers checkers1 = new Checkers(8);
        String notation = "21x14x23x16";

        checkers1.add(true, new int[][]{{5,2},{5,4},{5,6}});
        checkers1.add(false, new int[][]{{6,7}});
        checkers1.add(false, true,6,1);
        
        checkers1.swap();
        checkers1.move( notation );
        assertEquals( checkers1.getBoard()[5][0] , null);
        assertEquals( checkers1.getBoard()[4][1] , null);
        assertTrue( checkers1.getBoard()[5][4] ==  null );
        assertFalse( checkers1.getBoard()[3][6].getClass() ==  null );
        
        checkers1.swap();
        
    }

    @Test
    public void deberiaFuncionarInvisible()
    {
        Checkers checkers1 = new Checkers(8);
        checkers1.add(true, new int[][] {{4,3},{3,4}});
        checkers1.add(false, new int[][] {{5,2},{5,4}});
        checkers1.makeInvisible();
        assertFalse( checkers1.getBoard()[3][2].getClass() ==  null );
    }





    @Test
    public void deberiaSerLibertian() throws InterruptedException
    {
        Checkers checkers1 = new Checkers(8);
        checkers1.addDiferentTypes(false, 2, 4, 3);
        checkers1.add(true, new int[][]{{3,4},{3,6},{5,6},{5,4}});
        checkers1.select(4, 3);
        Thread.sleep(500);
        checkers1.jump(false, true);
        Thread.sleep(500);
        assertFalse(checkers1.getBoard()[5][4] == null );
        checkers1.select(6, 5);
        Thread.sleep(500);
        checkers1.jump(true, true);
        Thread.sleep(500);
        assertTrue(checkers1.getBoard()[3][6] != null );
        checkers1.select(4, 7);
        Thread.sleep(500);
        checkers1.jump(true, false);
        Thread.sleep(500);
        assertFalse(checkers1.getBoard()[1][4]  == null );
    }

    @Test
    public void mejorMovimiento() throws InterruptedException
    {
        Checkers checkers1 = new Checkers(8);
        checkers1.add(true,  new int[][]{{2,3},{4,5},{6,5}});
        checkers1.add(false, new int[][]{{4,3},{2,5}});
        checkers1.add(false, true, 3, 4);
        checkers1.swap();
        checkers1.select(3, 4);
        Thread.sleep(500);
        checkers1.move();
        Thread.sleep(500);
        assertTrue( checkers1.getBoard()[6][3].getClass() != null );
        checkers1.swap();
    }

    @Test
    public void deberiaComportarseProletarian() throws InterruptedException
    {
        Checkers checkers1 = new Checkers(8);
        checkers1.addDiferentTypes(true, 3, 7, 2);
        checkers1.addDiferentTypes(true, 3, 2,7);
        checkers1.addDiferentTypes(false, 3, 2, 3);
        checkers1.addDiferentTypes(false, 3, 3, 6);
        checkers1.select(2, 3);
        Thread.sleep(500);
        checkers1.shift(true, false);
        Thread.sleep(500);
        checkers1.select(7, 2);
        Thread.sleep(500);
        checkers1.shift(false, true);
        Thread.sleep(500);
        checkers1.select(3, 6);
        Thread.sleep(500);
        checkers1.jump(true,true);
        Thread.sleep(500);
        assertTrue(checkers1.getBoard()[0][7] == null);
        assertTrue(checkers1.getBoard()[0][1] == null);
        assertTrue(checkers1.getBoard()[7][2] == null);
    }

    @Test
    public void deberiaComportarsePowerful() throws InterruptedException
    {
        Checkers checkers1 = new Checkers(8);
        checkers1.addDiferentTypes(false , 5, 3, 4);
        checkers1.add(false, new int[][]{{5,2}});
        checkers1.add(true,new int[][] {{2,5}});
        checkers1.select(2, 5);
        Thread.sleep(500);
        checkers1.jump(false, false);
        assertTrue(checkers1.getBoard()[2][3] != null);
        Thread.sleep(500);
        checkers1.select(4, 3);
        Thread.sleep(500);
        checkers1.jump(false, false);
        assertTrue(checkers1.getBoard()[4][1] == null);
        Thread.sleep(500);
    }


    @Test
    public void deberiaComportarseHurried() throws InterruptedException
    {
        Checker.Checkers checkers1 = new Checker.Checkers(8);
        checkers1.addDiferentTypes(true, 7, 4, 3);
        checkers1.add(false, new int[][]{{5,4},{5,6},{3,6}});
        checkers1.select(4, 3);
        Thread.sleep(500);
        checkers1.jump(false, true);
        assertTrue(checkers1.getBoard()[5][4] == null);
        Thread.sleep(500);
    }

    @Test
    public void deberiaComportearceSuicide() throws InterruptedException
    {
        Checker.Checkers checkers1 = new Checker.Checkers(8);
        checkers1.add(true, true, 3, 4);
        checkers1.addDiferentTypes(false, 8, 4, 3);
        assertTrue(checkers1.getBoard()[4-1][3-1] != null);
        checkers1.select(4, 3);
        Thread.sleep(500);
        checkers1.jump(true, true);
        Thread.sleep(500);
        assertTrue(checkers1.getBoard()[4-1][3-1] == null);
        assertTrue(checkers1.getBoard()[3-1][4-1] == null);
        assertTrue(checkers1.getBoard()[2-1][5-1] == null);
    }

}

























