package Checker;

 
import Shape.*;
/**
 * Write a description of class Powerful here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Libertarian extends Piece
{
    

    /**
     * Constructor for objects of class Libertarian
     */
    public Libertarian(   Board board, Shapes shape, int f, int c, int type )
    {
        super(  board, shape, f, c,  2);
    }
    /**
     * this method override the method move of the class piece
     * @param finalF, is the row where the token want to move
     * @param finalC, is the column where the token want to move
     */
    @Override
    public void move( int finalF, int finalC ){
        super.moveTypes(finalF,finalC,2);
    }
    
    @Override 
    /***
     * method that seeks to skip a token given its meaning
     *@param top, boolean that say if the jump is going to do on the top
     *@param rigth ,boolean that say if the jump is going to do on the right 
     */
    public void jump(boolean top,boolean right, boolean show, int r, int c){
        int finalRow = ( top ) ? r - 2 : r + 2 , finalColumn = ( right ) ? c + 2 : c - 2  ;
        
        if ( show ){
            board.addDiferentTypes( getColor() == "green",2,finalRow + 1,finalColumn+1 );
            board.remove( new int[][] { { r + 1, c +1 }} ); 
        }
    } 
  

}
