package Checker;


 
import Shape.*;
/**
 * Write a description of class Powerful here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Lazy extends Piece
{
    /**
     * Constructor for objects of class Powerful
     */
    public Lazy(   Board board, Shapes shape, int f, int c , int type )
    {
        super(  board, shape, f, c ,4 );
        
    }
  

}