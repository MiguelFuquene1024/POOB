package Checker;


/**
 * class will simulate user history
 *
 * @author Iván Camilo Rincón Saavedra
 * @author Miguel Angel Fuquene Arias
 * 
 * @version 1.0 (05/04/2020)
 */
public class UserCase
{
    public UserCase()
    {
    }
    
    public Checkers juegoNormal() throws InterruptedException{
        Checkers checkers1 = new Checkers  ( 8 ) ;
        // Se establece una configuracion inicial, de dos diferentes equipos Rojo, Verde
        checkers1.add(false, new int[][]{{8,1},{8,3},{8,5},{8,7},{7,8},{7,2},{7,4},{7,6}});
        checkers1.add(true, new int[][]{{1,2},{1,4},{1,6},{1,8},{2,1},{2,3},{2,5},{2,7}});
        // se pasa al tablero de juego para empezar a mover sus fichas
        checkers1.swap();
        
        //movimientos realizados en el juego
        checkers1.move("5-9");
        checkers1.move("25-21");
        checkers1.move("9-14");
        checkers1.move("27-24");
        checkers1.move("8-11");
        checkers1.move("21-17");
        checkers1.move("14x21");
        checkers1.move("26-23");
        checkers1.move("7-10");
        checkers1.move("29-25");
        checkers1.move("11-15");
        checkers1.move("31-27");
        checkers1.move("1-5");
        checkers1.move("24-19");
        checkers1.move("15x24x31");
        checkers1.move("23-19");
        checkers1.move("4-8");
        checkers1.move("30-26");
        checkers1.move("21x30x23x16");
        return checkers1;
    }
    
    public void posiblesErroresOfallos() throws InterruptedException{
       Checkers checkers1 = new Checkers  ( 8 ) ;
       // errores de configuracion
       
       // Se establece una configuracion inicial, de dos diferentes equipos Rojo, Verde
       checkers1.add(false, new int[][]{{8,1},{8,3},{8,5},{8,7},{7,8},{7,2},{7,4},{7,6}});
       checkers1.add(true, new int[][]{{1,2},{1,4},{1,6},{1,8},{2,1},{2,3},{2,5},{2,7}});
       
       // se intenta añadir una ficha ya existente
       checkers1.add(false, new int[][]{{8,1}});
       
       // añadir una ficha en una casilla que no es permitida, (azul  claro)
       checkers1.add(false, new int[][]{{7,1}});
       
       // añadir una ficha en una casilla fuera del rango
       checkers1.add(false, new int[][]{{9,1}});
       
       //ahora pasamos a posibles errores y fallos del juego
       //mover una ficha a una casilla no vacia, funciona independientemente del color
       checkers1.add(false, new int[][]{{6,1},{4,5}});
       checkers1.add(true, new int[][]{{6,3}});
       
       checkers1.swap();
       checkers1.move("25-21");
       checkers1.move("25-22");
       
       //seleccionar una casilla la cual se encuentra vacia
       checkers1.select(4,3);
       
       //Saltar fichas que son del mismo color
       checkers1.move("25x18x11");
       
       //mover una ficha de manera inadecuada
       checkers1.move("5x23");
    }
    
    public void utilizandoElmejorMovimiento() throws InterruptedException{
        Checkers checkers1 = new Checkers  ( 8 ) ;
       // errores de configuracion
       
       // Se establece una configuracion inicial, de dos diferentes equipos Rojo, Verde
       checkers1.add(false,new int[][] {{5,2},{7,4},{8,5},{5,6},{3,6}});
       checkers1.add(true, true, 3, 2);
       checkers1.add(true, true, 1, 2);
       checkers1.swap();
       checkers1.move("9-13");
       checkers1.move("31-27");
       checkers1.select(4, 1);
       checkers1.move();
 
    }
    
    public void guardandoYrecuperandoTablero() throws InterruptedException{
        Checkers checkers1 = juegoNormal();
        checkers1.save("CurrentGame");
        checkers1.swap();
        checkers1.reset();
        checkers1.add(false,new int [][]{{3,4},{3,6},{5,6},{5,4},{3,2}});
        checkers1.add(true,new int [][]{{4,3}});
        checkers1.swap();
        checkers1.move("9-5");
        Thread.sleep(500);
        checkers1.move("14-17");
        Thread.sleep(500);
        checkers1.move("5-1");
        Thread.sleep(500);
        checkers1.move("17-21");
        Thread.sleep(500);
        checkers1.move("1-6");
        Thread.sleep(500);
        checkers1.swap();
        checkers1.reset();
        
        checkers1.read(checkers1.recover("CurrentGame"));


    }
    
    public void jugandoConLibertarianProletarianSuicida() throws InterruptedException{
        Checkers checkers1 = new Checkers  ( 8 ) ;
        // errores de configuracion
       
        // Se establece una configuracion inicial, de dos diferentes equipos Rojo, Verde
        //libertarian
        checkers1.addDiferentTypes(true, 2, 2, 1);
        checkers1.addDiferentTypes(true, 2, 2, 7);
        //suicide
        checkers1.addDiferentTypes(true, 8, 3, 4);
        //proletarian
        checkers1.addDiferentTypes(true, 3, 2, 3);
        checkers1.addDiferentTypes(true, 3, 2, 5);
        //pawn
        checkers1.add(false, new int[][] {{8,1},{8,3},{8,5},{8,7},{7,8},{7,2},{7,4},{7,6}});
        checkers1.add(true, new int[][]  {{1,2},{1,4},{1,6},{1,8}});
        checkers1.swap();
        checkers1.move("25-21");
        checkers1.move("10-14");
        checkers1.move("21-17");
        checkers1.move("14x21");
        checkers1.move("5-9");
        checkers1.move("27-23");
        checkers1.move("9-14");
        checkers1.move("23-18");
        checkers1.move("14x23");
        checkers1.move("26x19");
        checkers1.move("6-9");
        checkers1.move("18-14");
        checkers1.move("9x18");
        checkers1.move("30-25");
        checkers1.move("1-5");
        checkers1.move("25-22");
        checkers1.move("18x25");
        checkers1.move("32-27");
        checkers1.move("25-30");
 
    }
}
