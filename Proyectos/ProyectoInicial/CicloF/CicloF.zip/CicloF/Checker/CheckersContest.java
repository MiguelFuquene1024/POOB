package Checker;


/**
 * 
     * The  class that  will be simulate and solve the problem
     *Checks Post Facto from IPC( International Collegiate Programming Contest)
     * @author Iván Camilo Rincón Saavedra
     * @author Miguel Angel Fuquene Arias
     * 
     * @version 10.0 (5/04/2020)
     */
public class CheckersContest
{
    /**
     * Constructor for objects of class CheckersContest
     */
    public CheckersContest()
    {
 
    }
    
    /**
     * method that solve the problem Checks Post Facto from IPC( International Collegiate Programming Contest)
     *@param String, that represents the player that starts the game 
     *@param String[], the movements that is going to make the problem
     */
    public String[] solve(String player,String[] movements){
        SolveProyecto solution = new SolveProyecto();
        String[] rta = solution.solve(player,movements);
        return rta; 
    }
    
    /**
     * method that simulate the problem Checks Post Facto from IPC( International Collegiate Programming Contest) using the clas checker
     *@param String, that represents the player that starts the game 
     *@param String[], the movements that is going to make the problem
     *@boolean 
     */
    public void simulate(String player,String[] movements,boolean slow ) throws InterruptedException {
        
       Checkers checker = new Checkers( 8 );
       String[] rta =  solve(player,movements );
       checker.read( rta[1]);
       checker.save("final");
       checker.read( rta[0] );
       checker.save("inicio");
       checker.swap();
       if ( slow == false  ){
           checker.read(checker.recover("final"));
       }
       else{
           for ( String m: movements ){
                checker.move(m);
           }
        }
    
    }
}