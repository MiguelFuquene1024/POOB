package Checker;

 
import Shape.*;
/**
 * Write a description of class Pawn here.
 *
 *  @author Iván Camilo Rincón Saavedra
 * @author Miguel Angel Fuquene Arias
 */
public  class Pawn extends Piece
{
    /**
     * Constructor for objects of class Pawn
     */
    public Pawn(   Board board, Shapes shape, int f, int c, int type )
    {
        super(  board, shape, f, c, 6 );
        
    }
    
    /**
     * @param finalF, is the row where the token want to move
     * @param finalC, is the column where the token want to move
     */
    public  void move(  int finalF, int finalC ){
        String color = getColor();
        if ( ( f == 0 &&  "red".equals( color ) ) || ( f == board.size-1   && "green".equals( color ) ) ){
             cambio(finalF,finalC ); 
        }
        else {
            board.remove( f + 1  , c + 1);                        
            board.add( color == "green",getType() == 1, finalF + 1 , finalC + 1);  
        }
        
    }
   
  

}
