package Checker;

 
import Shape.*;
/**
 * This class extends the class piece and create a new type of piece(Powerful).
 * 
 * @author Miguel Angel Fuquene Arias
 * @author Ivan Camilo Rincon
 * @version 1.0
 */
public class Powerful extends Piece
{
    /**
     * Constructor for objects of class Powerful
     */
    public Powerful(   Board board, Shapes shape, int f, int c, int type )
    {
        super(  board, shape, f, c,5 );
    }
    
    @Override
    /**
     * method that moves a piece in the direction it is assigned
     * @param finalF, is the row in which will be the token then a movement.
     * @param finalC, is the column in which will be the token then a movement.
     */
    public  void move(  int finalF, int finalC ){
        super.moveTypes( finalF,finalC, 5);
    }
}