package Checker;

 

import Shape.*;
import java.util.ArrayList;

/**
     * It is a class that receives a figure, which in this case will represent
     * a piece of the game checkers and additionally several behaviors are 
     * created to these pieces.
     *
     * @author Iván Camilo Rincón Saavedra
     * @author Miguel Angel Fuquene Arias
     * 
     * @version 1.0 (04/02/2020)
     * @version 2.0 (05/02/2020)
     * @version 3.0 (06/02/2020)
     * @version 4.0 (03/03/2020)
     * @version 5.0 (03/03/2020)
     */
public  class Piece {
    protected Board board;
    protected Shapes shape;
    protected int f, c, type;
    protected String bestMove;
    
    /**
     *  This builder receives a figure along with the board it belongs to and
     *  is saying that this figure will be represented as a checker.
     *   
     * @param board,It is the board to which the checker belongs
     * @param shape, It is the figure that will be represented as a token
     * @param f,It is the row assigned to the checker inside the board
     * @param c,It is the column assigned to the checker inside the board
     * @param type, is the type that is assigned to the card to know if it is 
     * a strong token;
     */
    public Piece( Board board, Shapes shape, int f, int c, int type ){
        this.shape = shape;
        this.board = board;
        this.f = f; this.c = c;
        this.type = type;
    }
    
    public  int getType(){
        return type;
    }
    /**
     * This method update the row and the column of a token that was already
     * move.
     * @param newF, is the new row that will assign to a token
     * @param newC, is the new column that will assign to a token
     */
    public void updateFC( int newF, int newC ){
        f = newF;  c = newC;
    }
    /**
     * this method return boolean true if a token should change to a king in 
     * case when the token is in the first row or in a final row.
     * @param f, is the row where it will be evaluated if it should change to a king
     * @param c,is the column where it will be evaluated if it should change to a king 
     * @return a boolean indicate if the token in this positions should change to king
     */
    protected boolean changeKing( int fi, int co){
        boolean ok = false;
        if ( ( fi  == 0 &&  "red".equals( getColor() ) ) || ( fi == board.size -1  && "green".equals( getColor() ) ) ){
            ok = true;
        }
        return ok;
    }
    /**
     * This method replace any token to a king.
     */
    public void cambio( int finalF,int finalC) {
        
        String color = board.getPiece(f,c).getColor();
        board.remove( f + 1  , c + 1); 
        board.addDiferentTypes( color == "green", 1, finalF + 1 , finalC + 1);
        updateFC( finalF, finalC );
    }
    
    /**
     * This method change a token in some ubication for a king or an other type of
     * token.
     * @param finalF, is the row in which will be the new token
     * @param finalC, is the column in which will be the new token
     * @param type, is the type of the token that replacethe previous token
     */
    public  void moveTypes(  int finalF, int finalC, int type ){
        String color = getColor();
        if ( changeKing( finalF, finalC ) ){
            cambio( finalF, finalC ); 
        }
        else {
            board.remove( f + 1  , c + 1);                        
            board.addDiferentTypes( color == "green", type, finalF + 1 , finalC + 1);
            updateFC( finalF, finalC );
        }
        
    }
    
    /**
     * method that moves a piece in the direction it is assigned
     * @param finalF, is the row in which will be the token then a movement.
     * @param finalC, is the column in which will be the token then a movement.
     */
    public  void move(  int finalF, int finalC ){
        String color = getColor();
        if (  changeKing( finalF, finalC ) ){
            
            cambio( finalF,finalC); 
        }
        else {
            board.remove( f + 1  , c + 1);                        
            board.add( color == "green",getType() ==  1 , finalF + 1 , finalC + 1);
            updateFC( finalF, finalC );
        }
        
    }
    /**
     * This method evaluate if a token is a power token or no
     * @param rowTemp, is the row of the token that evaluate if is a power token
     * @param columnTemp, is the column of the token that evaluate if is a power token
     * @param f, is the row in which will be remove the token if is type=5
     * @param c, is the column in which will be remove the token if is type=5
     */
    protected void  checkPower( int rowTemp, int columnTemp, int f, int c ){
        if  ( board.getPiece(rowTemp,columnTemp).getType() != 5) {
            board.remove( rowTemp + 1, columnTemp + 1);
        } ;
        board.remove( f + 1, c + 1);
    }
    /***
     * method that seeks to skip a token given its meaning
     *@param top, boolean that say if the jump is going to do on the top
     *@param rigth ,boolean that say if the jump is going to do on the right
     *@param show, bollean that say if a token can jump or no
     *@parm r, is the row since the token want to jump
     *@param c, is the column since the token want to jump
     */
    public void jump(boolean top,boolean right, boolean show, int r, int c){
        int finalRow = ( top ) ? r - 2 : r + 2 , finalColumn = ( right ) ?   c + 2 :  c - 2  ;
        int rowTemp = ( top ) ? r - 1 : r + 1 ,columnTemp = ( right ) ?  c + 1 :  c - 1  ;
        if ( show ){
            board.add( getColor() == "green",getType() == 1,finalRow + 1,finalColumn+1 );
            checkPower(  rowTemp,  columnTemp,  r, c );
        }
        
    } 
    
    /**
     *  method that return the best movement of a piece
     *  @return String , thats represent the best move of a piece
       */
    public String moveString(  ) throws InterruptedException{
        this.bestMove = "";
        move();
        return this.bestMove;
    }
    
    /**
     * method that try all the posibilities of a move
     * @param row, int that represent a position on a matrix.
     * @param column , int that represent a position on a matrix.
       */
    protected void backTracking( int row, int column  ){
        boolean valid = board.checkPos( row +1, column+1,true,false ); 
        if ( valid ){         
            this.bestMove+= "x" + board.board[row][column].getNum();
            board.select( row + 1 , column + 1 );
        }
        if ( valid && board.canJump( row, column, row - 2  , column + 2 ,true,true ) ) {
            board.jump( true, true, true );
            backTracking(  row - 2  , column + 2 );
        }
        
        if ( valid && board.canJump( row, column, row + 2  , column + 2 ,false,true ) ) {
            board.jump( false, true, true );
            backTracking(   row + 2  , column + 2  );
        }
        
        if ( valid && board.canJump( row, column, row + 2  , column - 2 ,false,false ) ) {
            board.jump( false, false, true );
            backTracking(  row + 2  , column - 2   );
        }
        if ( valid && board.canJump( row, column, row - 2  , column - 2 ,true,false ) ) {
            board.jump( true, false, true );
            backTracking(  row - 2  , column - 2 );
        }
    }
    
    /**
      * method that moves a piece  with the best movement
    */
    public void move()   throws InterruptedException{
        board.select(f + 1, c + 1);
        backTracking( f, c  );
        board.select(f + 1, c + 1);

    }
    
    /**
     * method that set the position from which the board is drawn
     * @param newPos ,enter the new start position of the board 
     */
    public  void setXpos( int newXpos ){
        shape.setXpos( newXpos );
        
    };
    
    /**
     * method that get the position from which the rectangle is drawn
     * @return xPosition , the x Position of one rectangle
     */
    public int getXpos( ){
        return shape.getXpos()  ;
    }
    
    /**
     * method that set the y position from which the rectangle is drawn
     *  @return yPosition , the y Position of one rectangle
     */
    public   void setYpos( int newYpos ){
        shape.setYpos( newYpos );
    };
    
    /**
     * method that get the y position from which the rectangle is drawn
     * @return yPosition ,return the y Position of one rectangle
     */
    
    public int getYpos( ){
        return  shape.getXpos()  ;
    }
    
    /**
     * method that  Set the color. 
     * @param color the new color. Valid colors are "red", "yellow", "blue", "green",
     * "magenta" and "black".
     */
    public  void setColor( String newColor ){
        shape.setColor( newColor);   
    }

    /**
       * method that places  visible the piece
       * 
       */
    public  void  makeVisible(){
        shape.makeVisible();
    }
    
    
    /**
       * method that places  invisible the piece
       * 
       */
    public  void makeInvisible(){
        shape.makeInvisible();
    }
    
    
    /**
       *method that returns the current color of the piece
       *@return color, String that represents the color
       
       */
    public String getColor(){
        return shape.getColor();
    }
    
    
    /**
       *method thats save current color and set a new color to the piece
       *@param currentColor, String that represent the current color of the piece
       *@param newColor, String that represent the new color of  the piece
       */
    public  void temporalColor( String currentColor, String newColor  ){
        shape.temporalColor( currentColor, newColor);
        
    };
    
    
   
}