package aplicacion;

public class Sorpresa {
	protected int xPosition;
	protected int yPosition;
	
	
	public Sorpresa(){
	}
	
}
