package aplicacion;
/**
 * clase que representa a el CPU  
 * 
 * @author Miguel Angel Fuquene Arias 
 * @author Ivan Camilo Rincon Saavedra
 * 
 * @version 1.0 20/04/2020
 *     
 * */
public class Maquina extends Jugador {

	public Maquina(String name, Personaje p) {
		super(name, p);
		// TODO Auto-generated constructor stub
	}

}
