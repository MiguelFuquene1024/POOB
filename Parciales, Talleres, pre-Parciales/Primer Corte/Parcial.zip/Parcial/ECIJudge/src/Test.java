
public class Test {
    private int order;
    private Data input;
    private Data output;

}
