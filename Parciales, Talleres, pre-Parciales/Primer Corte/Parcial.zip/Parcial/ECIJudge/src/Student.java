
public class Student {
    private int code;
    private String name;

}
