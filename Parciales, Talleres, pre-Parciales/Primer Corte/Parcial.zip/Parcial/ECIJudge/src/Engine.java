
import java.time.Duration;

public class Engine {

    public static boolean execute(String sourceCode, String input, String output, Duration maxTime) {
        return false;
    }

}
