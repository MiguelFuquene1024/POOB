package aplicacion;
/**
 * clase que representa a el personaje de la CPU  
 * 
 * @author Miguel Angel Fuquene Arias 
 * @author Ivan Camilo Rincon Saavedra
 * 
 * @version 1.0 15/04/2020
 *     
 * */
public class PersonajeCPU extends Personaje {
	private static final long serialVersionUID = 9183534352438238869L;
	

	/**
	 * constructor del PersonajeCPU  del juego POOng
	 *@param xPosition, double que representa la posicion en x del personaje
	 *@param yPosition, double que representa la posicion en y del personaje
	 *@param xMax, double[] que representa lo maximo que podra moverse el personaje en la primera posicion sera lo maximo a a la izquierda y en la segunda sera lo maximo a derecha
	 * */
	public PersonajeCPU(double xPosition, double yPosition, double[] xMax) {
		super(xPosition,yPosition,xMax);
	}
	
	/**
	 * metodo que se encarga de mover un personaje de una persona
	 * @param game, que representa el juego POOng 
	 * */
	public void move( POOng game ){	
		Pelota pelota = game.getPelota(0);
		Bloque bloque = game.getBloque();
		if( bloque.isActive() && (bloque.getDy() < 0) ){
			evadirBloque( bloque );
		}
		else{
			buscarPelota( pelota );
		}
	}
	
	
	/**
	 * metodo que se encarga de que la cpu evite el bloque
	 * @param bloque, el bloque a evitar
	 * */
	private void evadirBloque(Bloque bloque ){
		double xBloque = bloque.getXposition();
		if( xBloque < xPosition ){
			moveRight();
		}
		else{
			moveLeft();	
		}
		
	}
	
	
	/**
	 * metodo que se encarga que el jugador siga a la pelota 
	 * @param pelota, la pelota a seguir
	 * */
	private void buscarPelota( Pelota pelota){
		double xPelota = pelota.getXposition();
		if( xPelota < xPosition ){
			moveLeft();
		}
		else{
			moveRight();
		}		
	}

}
